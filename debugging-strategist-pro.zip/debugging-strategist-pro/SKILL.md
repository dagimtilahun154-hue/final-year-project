---
name: debugging-strategist-pro
description: Systematically investigate, reproduce, diagnose, fix, and verify software defects, failing tests, crashes, regressions, performance issues, integration failures, and production incidents. Use when a user asks to debug, troubleshoot, find a root cause, repair a failing build or test, analyze logs or stack traces, investigate incorrect behavior, or produce an evidence-backed debugging report. Do not use for ordinary feature development, broad architecture planning, or simple conceptual explanations without a concrete software problem.
---

# Debugging Strategist Pro

## Mission

Resolve software problems through evidence, controlled experiments, minimal safe changes, and repeatable verification. Do not guess, thrash, hide failures, or declare success without proof.

## Core operating contract

1. Separate facts from assumptions.
2. Reproduce before repairing whenever reasonably possible.
3. Change one causal variable at a time during investigation.
4. Prefer the smallest safe fix that addresses the root cause.
5. Preserve security, data integrity, public contracts, and existing behavior.
6. Verify the original failure and relevant adjacent behavior after the change.
7. Report limitations, unverified areas, and pre-existing failures honestly.

Use these evidence labels in notes and reports:

- `VERIFIED`: directly observed in code, output, logs, tests, runtime behavior, or an authoritative artifact.
- `INFERRED`: strongly supported by evidence but not directly observed.
- `PROPOSED`: a hypothesis, experiment, or candidate fix not yet confirmed.
- `UNKNOWN`: unavailable, ambiguous, or not yet investigated.
- `REJECTED`: tested and contradicted by evidence.

Never convert `INFERRED` or `PROPOSED` into `VERIFIED` without new evidence.

## Select an operating mode

Choose the narrowest suitable mode. Read `references/operating-modes.md` when mode selection affects the workflow.

- `guided`: explain key reasoning and pause before meaningful edits when the user is learning.
- `autonomous`: investigate, repair, and verify ordinary defects independently.
- `investigation-only`: diagnose and report; do not modify code.
- `incident`: restore safe service first, then identify the permanent corrective action.
- `regression`: identify what changed and isolate the introducing change.
- `performance`: measure before optimizing and compare before/after results.
- `flaky-test`: establish repetition, environment, timing, and state evidence before changing assertions.
- `security-sensitive`: preserve controls and require explicit approval for risky changes.

If no mode is specified, default to `autonomous` for ordinary repository work and `investigation-only` when write access is unavailable.

## Start-up protocol

Before changing files:

1. Restate the defect in one sentence using expected versus actual behavior.
2. Identify impact, affected scope, environment, and urgency.
3. Inspect repository guidance such as `AGENTS.md`, `README`, contribution rules, package scripts, test commands, and local instructions.
4. Check worktree state and avoid overwriting unrelated user changes.
5. Create or update a debugging session state using `scripts/init_debug_session.py` when the task is non-trivial.
6. Record confirmed facts, unknowns, and the first reproduction plan.

Do not ask for information that can be discovered safely from the repository, logs, tests, or environment. Ask only when a missing fact materially blocks safe progress.

## Investigation workflow

### Phase 1 — Define the failure precisely

Capture:

- expected behavior;
- actual behavior;
- exact error text or symptom;
- first known occurrence;
- affected users, roles, inputs, devices, environments, or releases;
- reproducibility and frequency;
- recent code, configuration, dependency, infrastructure, or data changes;
- current business or operational impact.

Distinguish the user-visible symptom from the technical failure point.

### Phase 2 — Build a narrow context map

Inspect only the highest-value context first:

1. failing command, test, request, or user flow;
2. stack trace frames and directly referenced symbols;
3. recent diffs and ownership boundaries;
4. callers, dependencies, state transitions, and data contracts;
5. tests covering the failing path;
6. wider repository search only when evidence requires it.

Use symbol-aware search, targeted file ranges, dependency graphs, request traces, and recent diffs before broad recursive reading.

For a complex system, read `references/integration-contract.md` and reuse metadata from a project orchestration skill when available.

### Phase 3 — Establish a baseline

Record before editing:

- the exact reproduction command or steps;
- current test, build, lint, and type-check results relevant to the issue;
- environment, runtime, package manager, and dependency versions when relevant;
- relevant logs, status codes, timings, resource usage, or screenshots;
- pre-existing unrelated failures;
- clean or dirty worktree state.

A baseline prevents false attribution and makes improvement measurable.

### Phase 4 — Reproduce or bound the uncertainty

Prefer, in order:

1. a deterministic automated test;
2. a focused command or API request;
3. a minimal reproduction;
4. exact manual steps;
5. trace or log evidence when direct reproduction is unsafe or unavailable.

If reproduction fails, do not stop automatically. Compare environments, inputs, state, timing, permissions, data, and versions. Mark the issue `not-reproduced` and continue with bounded investigation when evidence is still useful.

Read `references/debugging-playbooks.md` for issue-specific reproduction strategies.

### Phase 5 — Create a hypothesis matrix

Generate a short ranked set of plausible causes. Each hypothesis must include:

- ID;
- causal statement;
- supporting and contradicting evidence;
- confidence;
- cheapest discriminating experiment;
- risk of the experiment;
- status: `untested`, `testing`, `verified`, or `rejected`.

Rank by explanatory power and ease of falsification, not by convenience. Avoid more than five active hypotheses unless the evidence genuinely supports a wider search.

### Phase 6 — Run controlled experiments

For every experiment, record:

- hypothesis tested;
- exact change or command;
- expected observation;
- actual observation;
- conclusion;
- artifacts produced;
- whether the environment was restored.

Change one causal variable at a time. Temporary instrumentation must be clearly marked and removed or intentionally retained before closeout.

Useful techniques include:

- divide-and-conquer isolation;
- binary search through inputs, code paths, or commits;
- minimal reproducible examples;
- differential testing;
- boundary and property testing;
- request, event, and state-transition tracing;
- dependency substitution;
- database query and migration inspection;
- race and timing analysis;
- profiling and resource measurement;
- `git bisect` for regressions;
- fault injection in safe non-production environments.

### Phase 7 — Identify the causal chain

Document separately:

- `symptom`: what was observed;
- `failure_point`: where execution or behavior became incorrect;
- `trigger`: input, state, timing, permission, dependency, or event that exposed it;
- `root_cause`: the underlying defect or missing invariant;
- `contributing_factors`: conditions that increased likelihood or impact;
- `escape_point`: why existing tests, monitoring, review, or validation did not catch it.

Do not call the nearest failing line the root cause unless the causal chain supports it.

### Phase 8 — Design the repair

Before implementation, state:

- root cause confidence;
- files and symbols to change;
- invariant to restore;
- smallest safe repair;
- compatibility and migration implications;
- test plan;
- rollback or containment plan;
- risks and approval gates.

Prefer local repairs that restore an invariant. Use a broader refactor only when a local patch would preserve the causal defect or create unacceptable maintenance risk.

Read `references/safety-and-approval-gates.md` before risky work.

### Phase 9 — Implement safely

Follow repository conventions and preserve unrelated work. Do not:

- disable, delete, or weaken tests merely to obtain a pass;
- remove validation, authorization, rate limits, or error handling to hide a failure;
- swallow exceptions without a documented recovery strategy;
- hard-code secrets, environment-specific values, or temporary outputs;
- change a public API, schema, migration, dependency major version, or security boundary silently;
- mix unrelated refactoring with the defect repair;
- install dependencies that are not necessary for the verified repair.

Add a regression test when practical. The test should fail for the original defect and pass after the repair.

### Phase 10 — Verify with a confidence ladder

Run the strongest applicable layers:

1. original reproduction;
2. new regression test;
3. targeted unit or component tests;
4. related integration tests;
5. lint and static analysis;
6. type checking;
7. build or packaging;
8. adjacent user journeys;
9. security and permission checks;
10. performance comparison;
11. broader test suite when justified by risk and cost.

Record exact commands and observed outcomes. `Looks correct` is not verification.

For performance work, report measurement method, sample size, noise controls, baseline, result, and trade-offs. For flaky tests, repeat enough times to support a stability claim and state the run count.

### Phase 11 — Close out

The final response must include:

- concise problem summary;
- reproduction status;
- root cause and causal chain;
- evidence supporting the conclusion;
- files and behavior changed;
- verification commands and results;
- pre-existing or unresolved failures;
- remaining risk and rollback notes;
- recommended prevention or monitoring improvements.

Use the templates in `assets/` and the reporting rules in `references/output-contracts.md` for formal deliverables.

### Phase 12 — Preserve learning

When the repository permits it, update relevant tests, comments, runbooks, troubleshooting docs, architectural metadata, or monitoring. Capture only durable findings; do not commit noisy investigation logs unless they are useful to the team.

## Context and token efficiency

Use progressive disclosure:

1. session state and current failure;
2. exact error and failing path;
3. relevant symbols and tests;
4. recent changes and dependency edges;
5. wider module or repository context only when needed.

Maintain a compact session state so work can resume without repeating discovery. Summarize large logs and retain exact excerpts only when they are evidence. Do not repeatedly reread unchanged files.

## Risk and approval gates

Stop and obtain explicit approval before:

- destructive database operations or data-loss-prone migrations;
- production deployment, rollback, or configuration mutation;
- changing authentication, authorization, encryption, secrets, or trust boundaries;
- weakening security controls or observability;
- changing public APIs or externally consumed schemas;
- major dependency upgrades;
- irreversible infrastructure operations;
- large architectural refactors outside the stated scope;
- actions likely to incur meaningful cost or affect real users.

Continue with read-only investigation and a safe plan while awaiting approval when possible.

## Specialized playbooks

Load only the relevant sections:

- `references/debugging-playbooks.md`: runtime, API, database, frontend, mobile, CI, integration, concurrency, memory, and flaky-test playbooks.
- `references/stack-guides.md`: React, TypeScript, Node.js, Express, PostgreSQL/Supabase, SQLite, Flutter/Dart, Python, and container guidance.
- `references/evidence-model.md`: evidence quality, confidence calibration, and contradiction handling.
- `references/operating-modes.md`: mode behavior and escalation.
- `references/safety-and-approval-gates.md`: risk classes and approval requirements.
- `references/output-contracts.md`: concise and formal report formats.
- `references/integration-contract.md`: integration with project orchestration, issue trackers, and CI.
- `references/commercialization.md`: product tiers, packaging, licensing considerations, and customer-facing differentiation.

## Deterministic utilities

Use scripts when useful:

- `python scripts/init_debug_session.py "Issue title"`: create a structured local debugging session.
- `python scripts/verify_session.py <session-directory>`: check whether a session has enough evidence to claim resolution.
- `python scripts/validate_skill.py`: validate package structure and required metadata.

Do not execute scripts from an untrusted repository without inspecting them first.

## Definition of done

A defect is `resolved` only when:

- the causal explanation is evidence-backed;
- the original failure is no longer reproducible under the tested conditions;
- a regression test exists when practical;
- relevant verification passed or limitations are explicit;
- risky side effects were considered;
- temporary debug changes were removed or intentionally retained;
- the final report distinguishes verified facts from remaining uncertainty.

If these conditions are not met, report `mitigated`, `partially resolved`, `not reproduced`, or `investigation complete` rather than `fixed`.
