# Evidence and Confidence Model

## Evidence hierarchy

From strongest to weakest:

1. deterministic reproduction with captured output;
2. regression test that fails before and passes after;
3. runtime trace, debugger state, or authoritative logs tied to the event;
4. source-code path with confirmed inputs and state;
5. consistent differential comparison;
6. correlated timing or circumstantial evidence;
7. intuition or pattern match.

Use weaker evidence to form hypotheses, not to close the investigation.

## Confidence calibration

- `Very high`: multiple independent strong signals; causal experiment supports the conclusion.
- `High`: direct evidence and no material contradiction; limited uncertainty remains.
- `Medium`: evidence is consistent but reproduction or causal isolation is incomplete.
- `Low`: plausible explanation with sparse or indirect evidence.

Do not express confidence as precision theatre. Use simple labels and explain the missing evidence.

## Contradictions

When evidence conflicts:

1. preserve both observations;
2. check timestamps, environment, versions, inputs, identity, and source freshness;
3. prefer direct and reproducible evidence;
4. create an experiment that distinguishes the explanations;
5. downgrade confidence until resolved.

## Evidence ledger format

| ID | Claim | Label | Source | Time | Reproducible | Notes |
|---|---|---|---|---|---|---|
| E1 | API returns 401 with valid token | VERIFIED | test output | 10:41 | yes | local staging config |
| E2 | signing secret differs | INFERRED | config comparison | 10:45 | not yet | needs process env check |

## Forbidden claims

Never claim:

- a command ran when it was not observed;
- a test passed based on source inspection alone;
- production is healthy based only on local behavior;
- the root cause is known when only the failure point is known;
- a repair is regression-free when relevant tests were not run;
- an issue is security-safe solely because functionality works.
