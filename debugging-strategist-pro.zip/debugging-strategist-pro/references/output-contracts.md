# Output Contracts

## Concise closeout

```text
Status: resolved | mitigated | partially resolved | not reproduced | investigation complete

Problem:
Expected ... but observed ...

Root cause:
...

Evidence:
- VERIFIED: ...

Changes:
- path: behavior changed

Verification:
- command — result

Remaining risk:
...
```

## Formal root-cause report

Use `assets/root-cause-report.template.md`. Include executive summary, impact, timeline, detection, symptom, failure point, trigger, root cause, contributing factors, escape point, repair, verification, rollback, prevention, and open questions.

## Guided-learning response

Explain:

1. what is known;
2. current hypothesis;
3. why the next experiment distinguishes causes;
4. result and updated conclusion;
5. repair and verification.

Keep reasoning useful and evidence-based without exposing private hidden chain-of-thought.

## No-fix investigation report

State that files were not modified. Rank causes, show evidence, identify the recommended repair, list exact verification steps, and mark unknowns.

## Incident update

```text
Current status:
Impact:
Containment:
Evidence preserved:
Recovery action:
Observed result:
Next decision:
Risks:
```

## Quality rules

- Use exact commands and outcomes.
- Name files and symbols when useful.
- Avoid dumping large logs; quote only decisive excerpts.
- Separate pre-existing failures from regressions caused by the repair.
- Do not use “fixed” when only code was edited.
