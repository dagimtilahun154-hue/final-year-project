# Safety and Approval Gates

## Risk classes

### Class A — Read-only and reversible

Examples: reading code, inspecting logs, running existing tests locally, static analysis, isolated reproductions.

Proceed normally while preserving privacy and repository instructions.

### Class B — Low-risk development edits

Examples: targeted source repair, regression test, temporary local instrumentation, documentation update.

Proceed in autonomous mode if scope is clear and the worktree is protected.

### Class C — Material behavior or compatibility change

Examples: public API change, schema migration, dependency major upgrade, broad refactor, permission logic change.

Explain impact and obtain approval unless the user explicitly authorized this class of work.

### Class D — Production, destructive, financial, or trust-boundary action

Examples: production deployment or rollback, data deletion, credential rotation, disabling controls, infrastructure teardown, customer-visible mutation.

Require explicit approval and a rollback or recovery plan.

## Protected invariants

Do not weaken these to make a failure disappear:

- authentication and authorization;
- tenant or user isolation;
- input validation and output encoding;
- encryption and secret handling;
- auditability and monitoring;
- data integrity and retention requirements;
- rate limiting and abuse controls;
- test integrity.

## Secret handling

Do not print, copy into reports, commit, or persist secrets. Redact tokens, passwords, keys, connection strings, personal data, and sensitive headers. Use fingerprints or last-four-character identifiers when correlation is necessary.

## Production incident discipline

Preserve evidence before mutation when practical. Record who authorized an action, exact command or change, time, expected effect, observed effect, and rollback status.
