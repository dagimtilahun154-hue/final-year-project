# Operating Modes

## Mode selection matrix

| Mode | Primary goal | Edits | Interaction | Strongest requirement |
|---|---|---:|---|---|
| Guided | Teach while solving | With checkpoints | High | Explain evidence and decisions |
| Autonomous | Resolve ordinary defects | Yes | Low | Verify before claiming success |
| Investigation-only | Diagnose without mutation | No | Low | Deliver evidence-backed report |
| Incident | Restore safe service | Minimal mitigation | Medium | Containment, rollback, timeline |
| Regression | Find introducing change | Usually | Low | Compare good and bad states |
| Performance | Improve measured bottleneck | Yes | Low | Before/after measurement |
| Flaky-test | Remove nondeterminism | Yes | Low | Repetition and state/timing evidence |
| Security-sensitive | Preserve trust boundaries | Controlled | High | Explicit approval for risky changes |

## Guided mode

Use when the user is learning or requests explanations. Show the current hypothesis, the experiment, and what the result means. Do not expose hidden chain-of-thought; provide concise, useful reasoning summaries and evidence.

Pause before edits that materially change behavior, dependencies, schemas, or architecture. Ordinary read-only inspection and harmless reproduction can continue.

## Autonomous mode

Use for standard repository defects with clear scope and safe write access. Continue through investigation, repair, and verification without unnecessary confirmation. Escalate only at an approval gate.

## Investigation-only mode

Do not modify source, configuration, dependencies, schemas, generated files, or tests. Temporary commands must be read-only or write only to an isolated scratch location. Produce a repair plan with confidence and verification strategy.

## Incident mode

Prioritize:

1. protect users and data;
2. stop expansion of impact;
3. preserve evidence;
4. restore a known-safe state;
5. communicate current status;
6. identify permanent corrective action.

Do not perform destructive production actions without explicit authorization. Distinguish containment, mitigation, rollback, recovery, and permanent repair.

## Regression mode

Establish at least one known-good and one known-bad state. Compare code, configuration, dependencies, data shape, environment, and build artifacts. Prefer targeted `git bisect` or change-set reduction when reproducible and safe.

## Performance mode

Define a measurable target. Control warm-up, caching, dataset, concurrency, network, and environment. Report median and tail behavior when possible. Do not optimize an unmeasured theory.

## Flaky-test mode

Record run count, failure count, ordering, parallelism, environment, random seed, timing, shared state, network dependencies, and cleanup behavior. Never solve flakiness by simply increasing retries or timeouts unless it is a documented temporary mitigation.

## Security-sensitive mode

Treat authentication, authorization, secrets, cryptography, tenant isolation, audit logging, input validation, and privilege boundaries as protected invariants. A passing test is insufficient if the repair weakens a control.
