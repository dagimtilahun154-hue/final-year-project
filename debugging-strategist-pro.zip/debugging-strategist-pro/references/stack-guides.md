# Stack-Specific Guides

These are checklists, not substitutes for repository-specific evidence.

## React and TypeScript

Check component identity, keys, controlled versus uncontrolled inputs, effect dependencies, stale closures, state mutation, memoization, context re-renders, Suspense/error boundaries, hydration, route transitions, query-cache keys, and TypeScript narrowing. Use React DevTools and browser network/console evidence when available.

## Node.js and Express

Check async error propagation, missing `await`, promise rejection handling, middleware order, request lifecycle, stream completion, connection pooling, event-loop blocking, process environment, module format, serialization, timeouts, and graceful shutdown. Correlate logs per request.

## PostgreSQL and Supabase

Check row-level security, JWT claims, schema search path, migrations, foreign keys, transaction isolation, indexes, query plans, generated types, null/default behavior, realtime subscriptions, and service-role misuse. Test policies with representative roles rather than privileged credentials only.

## SQLite

Check connection ownership, transaction boundaries, locking, WAL mode, foreign-key enforcement, type affinity, migration state, file path, concurrent writers, and test database isolation.

## Flutter and Dart

Check widget lifecycle, `BuildContext` validity, mounted state, state ownership, async gaps, streams/subscriptions, disposal, navigation stack, provider/bloc state, isolates, platform channels, permissions, release mode, and device-specific layout. Capture `flutter doctor`, build mode, platform, and logs when relevant.

## Python

Check virtual environment, interpreter version, import path, mutable defaults, async event loop, exception boundaries, dependency lock, serialization, timezone, subprocess behavior, and test fixtures. Use traceback origin and minimal input.

## Containers

Check image tag/digest, build context, Dockerfile layer cache, architecture, user/permissions, mounted paths, environment, health checks, network names, ports, startup ordering, resource limits, and signal handling. Compare container and host behavior explicitly.

## Web browsers

Check cache/service worker, extensions, cookies, storage, CORS, CSP, mixed content, network proxy, browser version, viewport, accessibility settings, and device emulation. Reproduce in a clean profile when appropriate.
