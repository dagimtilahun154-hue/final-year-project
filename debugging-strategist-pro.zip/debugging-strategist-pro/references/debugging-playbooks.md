# Debugging Playbooks

Load only the section relevant to the current defect.

## Build or compilation failure

1. Capture the exact command and first meaningful error.
2. Confirm runtime, compiler, package manager, lockfile, and generated artifacts.
3. Separate environment failure from source failure.
4. Inspect the earliest causal error, not every downstream error.
5. Compare with the last known-good build or CI environment.
6. Verify clean install only when dependency state is genuinely suspect.

## Runtime crash

1. Capture stack trace, input, environment, and state.
2. Identify the first application-owned frame.
3. Confirm nullability, lifecycle, resource ownership, and error boundaries.
4. Reproduce with the smallest triggering input.
5. Add a regression test at the nearest stable contract.

## Incorrect business behavior

1. Translate the requirement into explicit invariants and examples.
2. Trace input transformation, decision rules, persistence, and output.
3. Check boundary conditions, locale/timezone, rounding, defaults, stale state, and permissions.
4. Compare an expected case with a failing case.
5. Repair the violated invariant rather than hard-coding the example.

## API failure

Inspect client request, DNS/TLS, routing, middleware, auth, validation, handler, downstream dependencies, transaction, serialization, and response mapping. Capture method, URL pattern, status, headers with secrets redacted, body shape, correlation ID, and timing.

For timeouts, split total latency across connection, queueing, application, database, downstream calls, and serialization.

## Database defect

Check schema version, migration order, constraints, transaction boundaries, isolation, indexes, query plan, null/default semantics, timezone, collation, permissions, connection pool, and data shape. Use read-only queries first. Never mutate production data without approval and backup/recovery consideration.

## Frontend rendering or state defect

Separate data retrieval, normalization, store state, component lifecycle, derived state, memoization, routing, hydration, browser compatibility, and visual layout. Inspect console, network, state transitions, and DOM/accessibility tree. Verify loading, empty, error, and permission states.

## Mobile defect

Capture device, OS, app version, build mode, permissions, connectivity, lifecycle state, and platform-specific logs. Check background/foreground transitions, navigation state, storage, deep links, keyboard, safe areas, and release-only optimizations.

## Authentication or authorization defect

Map identity establishment, credential validation, token/session issuance, propagation, expiry, refresh, revocation, role/permission evaluation, tenant scope, and audit logging. Never bypass a control to confirm functionality. Use non-sensitive test identities.

## Integration defect

Write the contract for both sides: endpoint/event, schema, required fields, version, ordering, idempotency, retries, timeouts, and ownership. Capture the exact payload at the boundary with sensitive fields redacted. Determine whether the producer, transport, or consumer violated the contract.

## CI/CD failure

Compare local and CI runtime, environment variables, permissions, checkout depth, caches, service containers, architecture, clocks, paths, and concurrency. Reproduce with the closest available container or command. Do not edit workflow YAML blindly before reading the failing step logs.

## Flaky test

Classify likely nondeterminism:

- shared mutable state;
- ordering dependence;
- race or timing;
- network/service instability;
- random data or seed;
- time/date/timezone;
- leaked resources;
- parallelism;
- eventual consistency;
- environment capacity.

Run repeated controlled batches and vary one dimension at a time.

## Memory or resource leak

Define the resource and expected lifecycle. Use repeated workload, heap/resource snapshots, allocation profiles, open-handle counts, and ownership tracing. Confirm that growth persists after steady state and garbage collection where relevant.

## Concurrency or race defect

Capture event ordering and shared state. Reduce concurrency while preserving the failure, introduce deterministic synchronization in tests, and check atomicity, locking, cancellation, retries, duplicate delivery, and idempotency.

## Performance regression

Establish good and bad versions under the same workload. Profile before editing. Attribute time or resources to a component, then validate the repair with controlled before/after runs and correctness checks.
