# Integration Contract

## With a Software Orchestrator skill

Consume, when available:

- system goal and scope;
- architecture and module map;
- roles and permissions;
- data model and API contracts;
- ownership boundaries;
- commands and environments;
- active work and recent decisions.

Return:

- issue ID and status;
- affected modules and contracts;
- verified causal chain;
- files and symbols changed;
- tests and commands run;
- new invariants or architectural findings;
- residual risks and follow-up tasks.

Do not overwrite orchestration metadata with unverified debugging theories.

## With issue trackers

A ticket update should include reproduction, severity, environment, evidence, root cause confidence, repair, verification, and remaining risk. Avoid copying secrets or sensitive logs.

## With CI

The skill may propose or create:

- focused regression tests;
- deterministic validation scripts;
- failure artifact retention;
- test sharding or isolation improvements;
- activation and behavior evals for the skill itself.

Do not silently change required checks or reduce coverage.

## With observability systems

Use correlation IDs, traces, metrics, and logs to test a hypothesis. Recommend new telemetry only when it closes a specific detection or diagnosis gap. Avoid high-cardinality or sensitive labels.

## Handoff state

A debugging session is handoff-ready when another engineer can reproduce the tested conditions, understand the causal chain, see the exact changes, rerun verification, and identify unresolved uncertainty without repeating the full investigation.
