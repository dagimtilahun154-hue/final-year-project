#!/usr/bin/env python3
"""Validate whether a debugging session supports its claimed status."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

RESOLUTION_STATUSES = {"resolved", "fixed"}
SUCCESS_VALUES = {"pass", "passed", "success", "successful", "verified"}


def is_success(value: object) -> bool:
    return isinstance(value, str) and value.strip().lower() in SUCCESS_VALUES


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify debugging session evidence.")
    parser.add_argument("session_directory")
    args = parser.parse_args()

    path = Path(args.session_directory) / "issue.json"
    if not path.exists():
        print(f"ERROR: missing {path}")
        return 2

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"ERROR: invalid JSON: {exc}")
        return 2

    errors: list[str] = []
    warnings: list[str] = []

    issue = data.get("issue", {})
    reproduction = data.get("reproduction", {})
    causal = data.get("causal_chain", {})
    repair = data.get("repair", {})
    verification = data.get("verification", {})

    for field in ("title", "status", "mode"):
        if not issue.get(field):
            errors.append(f"issue.{field} is required")

    status = str(issue.get("status", "")).lower()
    if status in RESOLUTION_STATUSES:
        if reproduction.get("status") not in {"verified", "reproduced"}:
            errors.append("resolved status requires a verified original reproduction")
        if not causal.get("root_cause"):
            errors.append("resolved status requires causal_chain.root_cause")
        if causal.get("confidence") not in {"high", "very-high", "very high"}:
            warnings.append("root-cause confidence is not high")
        if repair.get("status") not in {"implemented", "verified", "complete"}:
            errors.append("resolved status requires an implemented repair")
        if not is_success(verification.get("original_reproduction")):
            errors.append("resolved status requires original_reproduction verification to pass")
        if verification.get("regression_test") == "not-run":
            warnings.append("no regression test was run; explain why")
        if not repair.get("changed_files"):
            warnings.append("no changed files recorded")

    if not data.get("evidence"):
        warnings.append("evidence ledger is empty")
    if not data.get("hypotheses"):
        warnings.append("hypothesis matrix is empty")

    if errors:
        print("SESSION NOT READY")
        for item in errors:
            print(f"ERROR: {item}")
        for item in warnings:
            print(f"WARNING: {item}")
        return 1

    print("SESSION VALID")
    for item in warnings:
        print(f"WARNING: {item}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
