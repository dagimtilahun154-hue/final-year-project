#!/usr/bin/env python3
"""Create a structured debugging session directory using only the standard library."""

from __future__ import annotations

import argparse
import json
import re
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug[:80] or "issue"


def main() -> int:
    parser = argparse.ArgumentParser(description="Initialize a Debugging Strategist Pro session.")
    parser.add_argument("title", help="Human-readable issue title")
    parser.add_argument("--root", default=".agent/debugging", help="Parent directory for sessions")
    parser.add_argument("--mode", default="autonomous", choices=[
        "guided", "autonomous", "investigation-only", "incident",
        "regression", "performance", "flaky-test", "security-sensitive"
    ])
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    template_path = script_dir.parent / "assets" / "issue-state.template.json"
    if not template_path.exists():
        raise SystemExit(f"Template not found: {template_path}")

    data = deepcopy(json.loads(template_path.read_text(encoding="utf-8")))
    now = datetime.now(timezone.utc).isoformat()
    slug = slugify(args.title)
    session_dir = Path(args.root) / slug
    session_dir.mkdir(parents=True, exist_ok=False)

    data["issue"].update({
        "id": slug,
        "title": args.title,
        "mode": args.mode,
        "created_at": now,
        "updated_at": now,
    })

    (session_dir / "issue.json").write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    (session_dir / "notes.md").write_text(
        f"# {args.title}\n\n## Facts\n\n## Unknowns\n\n## Current hypothesis\n\n## Next experiment\n",
        encoding="utf-8",
    )
    (session_dir / "experiments.md").write_text(
        "# Experiments\n\n| ID | Hypothesis | Action | Expected | Observed | Conclusion |\n"
        "|---|---|---|---|---|---|\n",
        encoding="utf-8",
    )

    print(session_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
