#!/usr/bin/env python3
"""Validate the Debugging Strategist Pro package structure and SKILL.md metadata."""

from __future__ import annotations

import re
from pathlib import Path

REQUIRED_FILES = [
    "SKILL.md",
    "README.md",
    "VERSION",
    "references/debugging-playbooks.md",
    "references/evidence-model.md",
    "references/operating-modes.md",
    "references/safety-and-approval-gates.md",
    "references/output-contracts.md",
    "references/commercialization.md",
    "assets/issue-state.template.json",
    "scripts/init_debug_session.py",
    "scripts/verify_session.py",
    "evals/prompts.csv",
    "evals/rubric.md",
]


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---\n", 4)
    if end == -1:
        return {}
    result: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            result[key.strip()] = value.strip()
    return result


def main() -> int:
    root = Path(__file__).resolve().parent.parent
    errors: list[str] = []

    for relative in REQUIRED_FILES:
        if not (root / relative).exists():
            errors.append(f"Missing required file: {relative}")

    skill_path = root / "SKILL.md"
    if skill_path.exists():
        text = skill_path.read_text(encoding="utf-8")
        metadata = parse_frontmatter(text)
        if metadata.get("name") != "debugging-strategist-pro":
            errors.append("SKILL.md frontmatter name must be debugging-strategist-pro")
        description = metadata.get("description", "")
        if len(description) < 80:
            errors.append("SKILL.md description is too short for reliable activation")
        if not re.fullmatch(r"[a-z0-9-]+", metadata.get("name", "")):
            errors.append("Skill name must use lowercase letters, digits, and hyphens")

        references = set(re.findall(r"`((?:references|assets|scripts)/[^`]+)`", text))
        for relative in references:
            if " " in relative or "<" in relative:
                continue
            if not (root / relative).exists():
                errors.append(f"SKILL.md references missing path: {relative}")

    if errors:
        print("VALIDATION FAILED")
        for error in errors:
            print(f"- {error}")
        return 1

    print("VALIDATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
