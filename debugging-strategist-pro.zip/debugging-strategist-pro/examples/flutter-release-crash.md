# Example: Flutter Release-Only Crash

Capture device, OS, app version, release build logs, permissions, and minification/tree-shaking configuration. Compare release and debug dependencies, initialization order, platform channels, reflection/dynamic behavior, assets, and environment configuration. Verify on the affected device class and one adjacent supported device.
