# Example: React Login Returns 401

## Problem

Expected valid credentials to create a session. Observed HTTP 401 after a frontend configuration change.

## Investigation outline

1. Capture the exact request and redact credentials.
2. Call the endpoint directly to separate client and server behavior.
3. Compare request headers and body between known-good and failing clients.
4. Inspect environment-based API URL and auth middleware contract.
5. Test the highest-confidence hypothesis with one controlled change.
6. Add a regression test for request construction or server validation.
7. Verify login, refresh, logout, and role checks.

## Example causal chain

- Symptom: login form displays “invalid credentials.”
- Failure point: API middleware rejects the request.
- Trigger: client sends the token in the wrong header format.
- Root cause: shared request helper changed the authorization prefix.
- Escape point: tests mocked the helper output instead of asserting the actual header.
