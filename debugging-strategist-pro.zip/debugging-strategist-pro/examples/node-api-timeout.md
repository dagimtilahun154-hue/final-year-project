# Example: Node API Timeout

## Baseline

Measure total response time and split application, database, and downstream-call timing.

## Hypotheses

- missing database index;
- sequential downstream requests;
- event-loop blocking serialization;
- exhausted connection pool;
- retry amplification.

## Verification

Use the same dataset, concurrency, environment, warm-up, and sample size before and after. Confirm output correctness in addition to latency improvement.
