# Example: Flaky Integration Test

Run a controlled batch and record pass/fail, seed, order, parallelism, timing, service state, and cleanup. Test shared-state, race, and eventual-consistency hypotheses independently. Add deterministic synchronization or isolation; do not rely only on retries or a larger timeout.
