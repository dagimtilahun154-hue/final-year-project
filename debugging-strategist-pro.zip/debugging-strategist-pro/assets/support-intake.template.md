# Debugging Support Intake

## What should happen?

## What happens instead?

## Exact error or visible symptom

## Reproduction steps

## Frequency

## Affected environment, users, devices, roles, or data

## First noticed

## Recent changes

## Logs, screenshots, traces, failing tests, or links

## Business impact and urgency

## Changes already attempted

## Constraints or actions that require approval
