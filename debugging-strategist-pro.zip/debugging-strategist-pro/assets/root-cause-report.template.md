# Root-Cause Analysis Report

## Executive summary

**Status:**

**Problem:**

**Impact:**

**Resolution:**

## Environment and scope

- Environment:
- Version/commit:
- Affected users or components:
- First known occurrence:

## Reproduction

- Status:
- Steps or command:
- Observed output:
- Evidence artifacts:

## Timeline

| Time | Event | Evidence |
|---|---|---|
| | | |

## Causal analysis

- Symptom:
- Failure point:
- Trigger:
- Root cause:
- Contributing factors:
- Escape point:
- Confidence:

## Evidence ledger

| ID | Claim | Label | Source | Notes |
|---|---|---|---|---|
| | | | | |

## Repair

- Restored invariant:
- Files/symbols changed:
- Compatibility impact:
- Rollback plan:

## Verification

| Command or check | Result | Evidence |
|---|---|---|
| | | |

## Remaining risks and unknowns

-

## Prevention and follow-up

-
