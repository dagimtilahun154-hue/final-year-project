# Skill Evaluation

The prompt set tests:

- direct and implicit activation;
- non-activation boundaries;
- safety behavior;
- honesty under uncertainty;
- context efficiency;
- report quality.

Run representative prompts against the installed skill, capture the trace and artifacts, and score them using `rubric.md`. Add a regression case whenever a real use reveals a failure in activation, process, safety, or output.
