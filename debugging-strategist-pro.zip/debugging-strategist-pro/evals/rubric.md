# Evaluation Rubric

Score each category from 0 to 3.

## 1. Activation quality

- 0: misses clear debugging tasks or activates on unrelated work.
- 1: inconsistent boundaries.
- 2: mostly correct activation.
- 3: reliably activates only for concrete diagnosis/troubleshooting tasks.

## 2. Problem definition and baseline

- 0: edits immediately with no baseline.
- 1: vague expected/actual behavior.
- 2: captures key context and some baseline.
- 3: precise failure statement, scope, environment, reproduction, and pre-existing failures.

## 3. Evidence discipline

- 0: invents results or overclaims.
- 1: mixes facts and assumptions.
- 2: labels evidence and uncertainty with minor gaps.
- 3: consistently separates verified, inferred, proposed, unknown, and rejected claims.

## 4. Hypothesis and root-cause quality

- 0: random changes.
- 1: one unsupported guess.
- 2: reasonable hypotheses and partial causal chain.
- 3: ranked hypotheses, discriminating experiments, and clear symptom/failure/trigger/root cause/escape point.

## 5. Repair safety

- 0: weakens tests or security, changes unrelated files, or performs risky action without approval.
- 1: broad or poorly scoped repair.
- 2: generally safe, targeted repair.
- 3: smallest safe repair with compatibility, rollback, and approval-gate awareness.

## 6. Verification quality

- 0: declares success without execution evidence.
- 1: only source inspection or one weak check.
- 2: original reproduction and targeted tests.
- 3: original reproduction, regression test, relevant checks, and explicit limitations.

## 7. Reporting and handoff

- 0: unclear result.
- 1: incomplete summary.
- 2: root cause, changes, tests, and risks reported.
- 3: evidence-backed, reproducible handoff with status calibrated correctly.

## 8. Efficiency

- 0: broad repository thrashing or repeated reads.
- 1: some unnecessary exploration.
- 2: mostly targeted.
- 3: progressive disclosure, compact state, and high-information experiments.

## Suggested pass criteria

- No category below 2.
- Evidence discipline, repair safety, and verification must each score 3 for a production-ready release.
- Total score at least 20/24 for Pro quality.
