# Debugging Strategist Pro

A commercial-grade agent skill for systematic software debugging, root-cause analysis, safe repair, regression prevention, and evidence-backed verification.

## What makes it different

- Scientific hypothesis-and-experiment workflow
- Explicit evidence and confidence model
- Reproduction-first and baseline-first discipline
- Root cause, trigger, escape point, and contributing-factor analysis
- Minimal-fix and regression-test requirements
- Specialized modes for incidents, regressions, performance, flaky tests, and security-sensitive defects
- Token-efficient context navigation
- Structured session state and reusable reports
- Deterministic validation utilities
- Evaluation prompts and scoring rubric
- Commercialization guidance for packaging the skill as a paid product or service

## Package structure

```text
debugging-strategist-pro/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── VERSION
├── references/
├── assets/
├── scripts/
├── evals/
└── examples/
```

## Installation

### Repository-scoped

Copy the folder to:

```text
<repository>/.agents/skills/debugging-strategist-pro/
```

### User-scoped

Copy the folder to:

```text
$HOME/.agents/skills/debugging-strategist-pro/
```

Then start a new Codex session if the skill is not detected automatically.

## Invocation examples

```text
Use $debugging-strategist-pro to investigate why valid users receive 401 responses after the latest deployment.
```

```text
Use $debugging-strategist-pro in investigation-only mode. Find the root cause of this flaky integration test but do not modify files.
```

```text
Use $debugging-strategist-pro in performance mode. Measure and fix the slow product search endpoint, preserving its API contract.
```

```text
Use $debugging-strategist-pro in guided mode and teach me how you isolate this Flutter state-management bug.
```

## Recommended product positioning

The core package can be sold as a premium debugging workflow, while advanced playbooks, organization-specific integrations, CI automation, team reporting, and custom evals can form higher-priced plans. See `references/commercialization.md`.

## Validation

From this directory:

```bash
python scripts/validate_skill.py
```

Create a sample session:

```bash
python scripts/init_debug_session.py "Login returns 401"
```

Check whether the session supports a resolution claim:

```bash
python scripts/verify_session.py .agent/debugging/login-returns-401
```

## Evaluation

Use `evals/prompts.csv` to test activation and behavior. The rubric scores evidence discipline, reproduction quality, root-cause reasoning, safety, verification, reporting, and efficiency.

## Official references

- https://developers.openai.com/codex/build-skills
- https://developers.openai.com/blog/eval-skills

## Commercial note

This package contains productization ideas, not legal, tax, or financial advice. Obtain appropriate professional review before publishing terms, licenses, warranties, or pricing commitments.
