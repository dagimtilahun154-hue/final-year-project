# Changelog

## 1.0.0 — Initial Pro release

- Added evidence-based debugging workflow.
- Added guided, autonomous, investigation, incident, regression, performance, flaky-test, and security-sensitive modes.
- Added root-cause and escape-point analysis.
- Added approval gates and anti-pattern protections.
- Added stack-specific and issue-specific playbooks.
- Added structured session assets and deterministic validation scripts.
- Added evaluation prompt set and scoring rubric.
- Added commercialization and product-tier guidance.
