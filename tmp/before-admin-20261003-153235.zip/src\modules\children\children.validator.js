'use strict';
/**
 * src/modules/children/children.validator.js
 * Validation schemas for child profile registration, updates, and guardian linking.
 * SRS Refs: FR-CH-01, FR-CH-02, FR-CH-03, FR-CH-04
 */
const { Joi } = require('../../middleware/validator');

const createChildSchema = Joi.object({
  full_name: Joi.string().max(150).required(),
  dob: Joi.date().iso().required(),
  gender: Joi.string().valid('male', 'female', 'other'),
  group_id: Joi.number().integer().allow(null),
  caregiver_id: Joi.number().integer().allow(null),
  enrollment_status: Joi.string().valid('active', 'inactive', 'waitlist').default('active'),
  emergency_contacts: Joi.array().items(
    Joi.object({
      name: Joi.string().max(150).required(),
      relationship: Joi.string().max(80).required(),
      phone: Joi.string().max(30).required(),
    })
  ),
  care_instructions: Joi.array().items(
    Joi.object({
      category: Joi.string().valid('allergy', 'dietary', 'medical_note', 'general').required(),
      instruction_text: Joi.string().required(),
    })
  ),
});

const updateChildSchema = Joi.object({
  full_name: Joi.string().max(150),
  dob: Joi.date().iso(),
  gender: Joi.string().valid('male', 'female', 'other'),
  group_id: Joi.number().integer().allow(null),
  caregiver_id: Joi.number().integer().allow(null),
  enrollment_status: Joi.string().valid('active', 'inactive', 'waitlist'),
  photo_url: Joi.string().max(255).allow(null, ''),
}).min(1);

const addGuardianSchema = Joi.object({
  user_id: Joi.number().integer().required(),
  relationship: Joi.string().max(80).required(),
  pickup_authorized: Joi.boolean().default(false),
});

module.exports = {
  createChildSchema,
  updateChildSchema,
  addGuardianSchema,
};
