﻿'use strict'; module.exports = {};
