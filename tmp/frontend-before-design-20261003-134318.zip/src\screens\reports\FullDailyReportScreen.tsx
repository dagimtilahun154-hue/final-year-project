import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, ChatCircleDots, Quotes, CalendarBlank } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { ConnectedTimelineNode } from '../../components/ConnectedTimelineNode';
import { StatusBadge } from '../../components/StatusBadge';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type FullDailyReportScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'FullDailyReport'>;
};

export const FullDailyReportScreen: React.FC<FullDailyReportScreenProps> = ({ navigation }) => {
  const handleMessageCaregiver = () => {
    navigation.navigate('CaregiverChat', { threadId: 1 });
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Navigation Back Header */}
        <View style={styles.navHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
          >
            <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
          <View style={styles.headerTitles}>
            <Text style={styles.pageTitle}>Liya's Daily Report</Text>
            <Text style={styles.pageDate}>Tuesday, August 25, 2026</Text>
          </View>
          <StatusBadge status="at_daycare" />
        </View>

        {/* Check-in Banner */}
        <View style={styles.checkinBanner}>
          <CalendarBlank size={20} color={colors.pastelYellowText} weight="bold" />
          <Text style={styles.checkinBannerText}>
            Checked in at 8:04 AM by Hana T. • Sunflower Group
          </Text>
        </View>

        {/* Vertical Timeline */}
        <Text style={styles.sectionTitle}>ACTIVITY TIMELINE</Text>
        <View style={styles.timelineContainer}>
          <ConnectedTimelineNode
            isFirst
            category="checkin"
            time="8:04 AM"
            title="Arrived & Checked In"
            description="Checked in safely at the main entrance by Hana Tesfaye."
          />
          <ConnectedTimelineNode
            category="meals"
            time="8:30 AM"
            title="Healthy Breakfast"
            description="Ate oatmeal with sliced bananas and warm milk. Ate 100% portion."
          />
          <ConnectedTimelineNode
            category="learning"
            time="10:00 AM"
            title="Puzzles & Shape Matching"
            description="Participated actively in counting numbers 1-20 and sorting colored shapes."
          />
          <ConnectedTimelineNode
            category="play"
            time="11:15 AM"
            title="Playground & Ball Games"
            description="Enjoyed outdoor playtime on the slide and played tag with classmates."
          />
          <ConnectedTimelineNode
            category="meals"
            time="12:30 PM"
            title="Lunch Time"
            description="Ate Injera with mild vegetable stew and lentil soup. Finished full meal."
          />
          <ConnectedTimelineNode
            category="sleep"
            time="1:15 PM"
            title="Afternoon Nap"
            description="Slept peacefully for 1 hour and 45 minutes in the quiet rest area."
          />
          <ConnectedTimelineNode
            isLast
            category="art"
            time="3:15 PM"
            title="Creative Painting & Craft"
            description="Painted a bright sunflower using water colors and shared markers with peers."
          />
        </View>

        {/* Daily Summary Matrix */}
        <Text style={[styles.sectionTitle, { marginTop: 16 }]}>DAILY SUMMARY MATRIX</Text>
        <View style={styles.summaryMatrixCard}>
          <View style={styles.matrixRow}>
            <View style={styles.matrixItem}>
              <Text style={styles.matrixLabel}>MOOD</Text>
              <Text style={styles.matrixValue}>Happy & Bright 😃</Text>
            </View>
            <View style={styles.matrixItem}>
              <Text style={styles.matrixLabel}>BEHAVIOR</Text>
              <Text style={styles.matrixValue}>Cooperative 🤝</Text>
            </View>
          </View>
          <View style={[styles.matrixRow, styles.matrixBorderTop]}>
            <View style={styles.matrixItem}>
              <Text style={styles.matrixLabel}>HEALTH</Text>
              <Text style={styles.matrixValue}>Normal & Energetic 💚</Text>
            </View>
            <View style={styles.matrixItem}>
              <Text style={styles.matrixLabel}>GENERAL</Text>
              <Text style={styles.matrixValue}>Wonderful Day ✨</Text>
            </View>
          </View>
        </View>

        {/* Caregiver Note */}
        <Text style={[styles.sectionTitle, { marginTop: 24 }]}>CAREGIVER NOTE</Text>
        <View style={styles.caregiverCard}>
          <View style={styles.caregiverHeader}>
            <View style={styles.avatarCircle}>
              <Text style={styles.avatarText}>SM</Text>
            </View>
            <View>
              <Text style={styles.caregiverName}>Sara Mekonnen</Text>
              <Text style={styles.caregiverRole}>Lead Caregiver</Text>
            </View>
            <Quotes size={24} color={colors.accentGold} weight="fill" style={{ marginLeft: 'auto' }} />
          </View>
          <Text style={styles.caregiverNoteText}>
            "Liya had an amazing day! She showed great kindness by sharing her art supplies during painting time and ate all her meals enthusiastically."
          </Text>
        </View>

        {/* Bottom CTA */}
        <PillButton
          title="Message Caregiver"
          leftIcon={<ChatCircleDots size={20} color={colors.textWhite} weight="bold" />}
          onPress={handleMessageCaregiver}
          style={styles.messageBtn}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  navHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerTitles: {
    flex: 1,
  },
  pageTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  pageDate: {
    fontSize: 13,
    color: colors.textSecondary,
    marginTop: 2,
  },
  checkinBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.pastelYellow,
    padding: 14,
    borderRadius: radii.subcard,
    columnGap: 10,
    marginBottom: 24,
  },
  checkinBannerText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.pastelYellowText,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 14,
  },
  timelineContainer: {
    marginBottom: 10,
  },
  summaryMatrixCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  matrixRow: {
    flexDirection: 'row',
    paddingVertical: 8,
  },
  matrixBorderTop: {
    borderTopWidth: 1,
    borderColor: colors.borderLight,
    paddingTop: 14,
    marginTop: 6,
  },
  matrixItem: {
    flex: 1,
  },
  matrixLabel: {
    fontSize: 10.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 4,
  },
  matrixValue: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  caregiverCard: {
    backgroundColor: colors.bgNavyCard,
    borderRadius: radii.card,
    padding: 18,
    marginBottom: 24,
    ...shadows.card,
  },
  caregiverHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 12,
    marginBottom: 10,
  },
  avatarCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.accentGold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.bgNavy,
  },
  caregiverName: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textWhite,
  },
  caregiverRole: {
    fontSize: 12,
    color: colors.borderCard,
  },
  caregiverNoteText: {
    fontSize: 13.5,
    fontWeight: '400',
    color: colors.bgMuted,
    lineHeight: 20,
    fontStyle: 'italic',
  },
  messageBtn: {
    marginTop: 4,
  },
});
