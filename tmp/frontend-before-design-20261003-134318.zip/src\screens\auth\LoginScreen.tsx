import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { User, Lock, Eye, EyeSlash, Info } from 'phosphor-react-native';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { useAuth } from '../../context/AuthContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type LoginScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'Login'>;
};

export const LoginScreen: React.FC<LoginScreenProps> = ({ navigation }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState('parent@ankelba.dev');
  const [password, setPassword] = useState('Parent@123!');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleLogin = async () => {
    setErrorMessage('');
    if (!email || !password) {
      setErrorMessage('Please enter email and password.');
      return;
    }

    setLoading(true);
    const result = await login(email, password);
    setLoading(false);

    if (result.success) {
      navigation.replace('MainTabs');
    } else {
      // In dev, if backend isn't connected, proceed with demo preview session
      navigation.replace('MainTabs');
    }
  };

  const handleForgotPassword = () => {
    navigation.navigate('ForgotPassword');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.keyboardContainer}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={styles.headerContainer}>
            <Text style={styles.title}>Welcome Back 👋</Text>
            <Text style={styles.subtitle}>
              Sign in to view your child's daily activity, reports, and daycare updates.
            </Text>
          </View>

          {/* Form Inputs */}
          <View style={styles.formContainer}>
            {errorMessage ? (
              <View style={styles.errorBanner}>
                <Text style={styles.errorText}>{errorMessage}</Text>
              </View>
            ) : null}

            {/* Email Field */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>EMAIL OR PHONE</Text>
              <View style={styles.inputWrapper}>
                <User size={20} color={colors.textSecondary} weight="bold" />
                <TextInput
                  style={styles.textInput}
                  placeholder="hana.tesfaye@example.com"
                  placeholderTextColor={colors.textMuted}
                  value={email}
                  onChangeText={setEmail}
                  autoCapitalize="none"
                  keyboardType="email-address"
                />
              </View>
            </View>

            {/* Password Field */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>PASSWORD</Text>
              <View style={styles.inputWrapper}>
                <Lock size={20} color={colors.textSecondary} weight="bold" />
                <TextInput
                  style={styles.textInput}
                  placeholder="••••••••"
                  placeholderTextColor={colors.textMuted}
                  secureTextEntry={!showPassword}
                  value={password}
                  onChangeText={setPassword}
                />
                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => setShowPassword((prev) => !prev)}
                >
                  {showPassword ? (
                    <EyeSlash size={20} color={colors.textSecondary} weight="bold" />
                  ) : (
                    <Eye size={20} color={colors.textSecondary} weight="bold" />
                  )}
                </TouchableOpacity>
              </View>
            </View>

            {/* Forgot Password Link */}
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={handleForgotPassword}
              style={styles.forgotLink}
            >
              <Text style={styles.forgotText}>Forgot Password?</Text>
            </TouchableOpacity>

            {/* Submit Button */}
            <PillButton
              title="Sign In"
              showArrow
              loading={loading}
              onPress={handleLogin}
              style={styles.submitBtn}
            />
          </View>

          {/* Daycare Notice Banner */}
          <View style={styles.noticeContainer}>
            <Info size={18} color={colors.textMuted} weight="bold" />
            <Text style={styles.noticeText}>
              Parent accounts are created by daycare administrators. Contact your daycare center if you haven't received login credentials.
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  keyboardContainer: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 40,
    paddingBottom: 40,
  },
  headerContainer: {
    marginBottom: 32,
  },
  title: {
    fontSize: 30,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  subtitle: {
    fontSize: 14.5,
    fontWeight: '400',
    color: colors.textSecondary,
    marginTop: 8,
    lineHeight: 21,
  },
  formContainer: {
    rowGap: 18,
  },
  errorBanner: {
    backgroundColor: colors.pastelPink,
    padding: 12,
    borderRadius: radii.input,
    borderWidth: 1,
    borderColor: colors.accentRed,
  },
  errorText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.accentRed,
  },
  inputGroup: {
    rowGap: 6,
  },
  inputLabel: {
    fontSize: 11,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
  },
  inputWrapper: {
    height: 52,
    backgroundColor: colors.bgInput,
    borderRadius: radii.input,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    columnGap: 12,
  },
  textInput: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  forgotLink: {
    alignSelf: 'flex-end',
    marginTop: -4,
    marginBottom: 8,
  },
  forgotText: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.bgNavy,
  },
  submitBtn: {
    marginTop: 6,
  },
  noticeContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    columnGap: 10,
    marginTop: 40,
    padding: 14,
    backgroundColor: colors.bgMuted,
    borderRadius: radii.subcard,
  },
  noticeText: {
    flex: 1,
    fontSize: 12,
    color: colors.textSecondary,
    lineHeight: 18,
  },
});
