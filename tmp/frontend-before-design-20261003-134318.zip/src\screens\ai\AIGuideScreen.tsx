import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Sparkle, ArrowLeft, PaperPlaneRight, Lightbulb, User } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { SafetyDisclaimer } from '../../components/SafetyDisclaimer';
import { colors, radii, shadows } from '../../theme/tokens';
import { useChild } from '../../context/ChildContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type AIGuideProps = {
  navigation: StackNavigationProp<RootStackParamList, 'AIGuide'>;
};

interface AIMessage {
  id: number;
  sender: 'user' | 'ai';
  text: string;
  time: string;
}

const SUGGESTED_PROMPTS = [
  'Is 1h 45m nap time normal for a 4-year-old?',
  'What healthy Ethiopian snacks can I prepare for daycare?',
  'How to support bilingual learning (Amharic & English)?',
];

export const AIGuideScreen: React.FC<AIGuideProps> = ({ navigation }) => {
  const { selectedChild } = useChild();
  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: 1,
      sender: 'ai',
      text: `Hello Hana! I am your Ankelba AI Development Assistant. I can help analyze ${selectedChild?.full_name || 'Liya'}'s daily activity patterns, sleep duration, and nutritional habits. How can I assist you today?`,
      time: '10:00 AM',
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSendPrompt = (promptText: string) => {
    if (!promptText.trim()) return;

    const userMsg: AIMessage = {
      id: Date.now(),
      sender: 'user',
      text: promptText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsTyping(true);

    // Simulate AI response stream
    setTimeout(() => {
      let aiResponseText = `Based on standard early childhood guidelines for 4-year-olds: a afternoon nap of 1.5 to 2 hours is very healthy and promotes cognitive retention. ${selectedChild?.full_name || 'Liya'}'s 1h 45m nap today falls directly within the ideal range!`;
      if (promptText.includes('snack') || promptText.includes('Ethiopian')) {
        aiResponseText = `Great nutritious daycare snack options include: roasted barley (Kolo), steamed sweet potatoes, avocado mash with injera strips, and fresh papaya cubes. These provide long-lasting energy for active play!`;
      } else if (promptText.includes('bilingual') || promptText.includes('Amharic')) {
        aiResponseText = `Bilingual language growth is enriched when parents speak Amharic at home while daycare reinforces English during group storytelling. Reading bilingual picture books before bedtime works wonders!`;
      }

      const aiMsg: AIMessage = {
        id: Date.now() + 1,
        sender: 'ai',
        text: aiResponseText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Back Bar Header */}
          <View style={styles.navHeader}>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => navigation.goBack()}
              style={styles.backBtn}
            >
              <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
            </TouchableOpacity>
            <View>
              <View style={styles.titleRow}>
                <Text style={styles.pageTitle}>AI Care Assistant</Text>
                <Sparkle size={18} color={colors.accentGold} weight="fill" />
              </View>
              <Text style={styles.pageSubtitle}>Childhood growth & wellness guidance</Text>
            </View>
          </View>

          {/* SRS Legal AI Disclaimer */}
          <SafetyDisclaimer variant="ai" />

          {/* Quick Suggested Prompts Carousel */}
          <Text style={styles.sectionTitle}>SUGGESTED QUESTIONS</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.promptsRow}
          >
            {SUGGESTED_PROMPTS.map((prompt, idx) => (
              <TouchableOpacity
                key={idx}
                activeOpacity={0.8}
                onPress={() => handleSendPrompt(prompt)}
                style={styles.promptChip}
              >
                <Lightbulb size={14} color={colors.accentGold} weight="bold" />
                <Text style={styles.promptChipText}>{prompt}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Chat Stream */}
          <View style={styles.chatStream}>
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <View
                  key={msg.id}
                  style={[
                    styles.messageWrapper,
                    isUser ? styles.userWrapper : styles.aiWrapper,
                  ]}
                >
                  <View
                    style={[
                      styles.messageBubble,
                      isUser ? styles.userBubble : styles.aiBubble,
                    ]}
                  >
                    {!isUser && (
                      <View style={styles.aiBadgeHeader}>
                        <Sparkle size={14} color={colors.accentGold} weight="fill" />
                        <Text style={styles.aiBadgeTitle}>ANKELBA AI</Text>
                      </View>
                    )}
                    <Text
                      style={[
                        styles.messageText,
                        isUser ? styles.userText : styles.aiText,
                      ]}
                    >
                      {msg.text}
                    </Text>
                    <Text
                      style={[
                        styles.timeText,
                        isUser ? styles.userTime : styles.aiTime,
                      ]}
                    >
                      {msg.time}
                    </Text>
                  </View>
                </View>
              );
            })}

            {isTyping && (
              <View style={[styles.messageWrapper, styles.aiWrapper]}>
                <View style={[styles.messageBubble, styles.aiBubble]}>
                  <Text style={styles.typingText}>Ankelba AI is thinking...</Text>
                </View>
              </View>
            )}
          </View>
        </ScrollView>

        {/* Input Bar */}
        <View style={styles.inputBar}>
          <TextInput
            style={styles.inputField}
            placeholder="Ask AI about child nutrition, sleep, growth..."
            placeholderTextColor={colors.textMuted}
            value={inputQuery}
            onChangeText={setInputQuery}
          />
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => handleSendPrompt(inputQuery)}
            style={styles.sendBtn}
          >
            <PaperPlaneRight size={18} color={colors.textWhite} weight="bold" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  navHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 6,
  },
  pageTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  pageSubtitle: {
    fontSize: 12.5,
    color: colors.textSecondary,
    marginTop: 1,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginTop: 14,
    marginBottom: 10,
  },
  promptsRow: {
    columnGap: 8,
    paddingBottom: 16,
  },
  promptChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgSurface,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: radii.pill,
    columnGap: 6,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  promptChipText: {
    fontSize: 12.5,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  chatStream: {
    rowGap: 14,
    marginTop: 10,
  },
  messageWrapper: {
    width: '100%',
    flexDirection: 'row',
  },
  userWrapper: {
    justifyContent: 'flex-end',
  },
  aiWrapper: {
    justifyContent: 'flex-start',
  },
  messageBubble: {
    maxWidth: '85%',
    borderRadius: radii.card,
    padding: 16,
    ...shadows.card,
  },
  userBubble: {
    backgroundColor: colors.bgNavy,
    borderBottomRightRadius: 4,
  },
  aiBubble: {
    backgroundColor: colors.bgSurface,
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  aiBadgeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 6,
    marginBottom: 8,
  },
  aiBadgeTitle: {
    fontSize: 11,
    fontWeight: '800',
    color: colors.accentGold,
    letterSpacing: 0.6,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 21,
  },
  userText: {
    color: colors.textWhite,
  },
  aiText: {
    color: colors.textPrimary,
  },
  timeText: {
    fontSize: 10.5,
    marginTop: 6,
    textAlign: 'right',
  },
  userTime: {
    color: colors.borderCard,
  },
  aiTime: {
    color: colors.textSecondary,
  },
  typingText: {
    fontSize: 13,
    fontStyle: 'italic',
    color: colors.textSecondary,
  },
  inputBar: {
    height: 64,
    backgroundColor: colors.bgSurface,
    borderTopWidth: 1,
    borderColor: colors.borderLight,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    columnGap: 10,
  },
  inputField: {
    flex: 1,
    height: 44,
    backgroundColor: colors.bgInput,
    borderRadius: radii.input,
    paddingHorizontal: 16,
    fontSize: 13.5,
    color: colors.textPrimary,
  },
  sendBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: colors.bgNavy,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
