import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Trash, Plus, Minus, CreditCard, ShieldCheck } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { useChild } from '../../context/ChildContext';
import { useAuth } from '../../context/AuthContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type ShoppingCartProps = {
  navigation: StackNavigationProp<RootStackParamList, 'ShoppingCart'>;
};

export const ShoppingCartScreen: React.FC<ShoppingCartProps> = ({ navigation }) => {
  const { cart, removeFromCart, updateQuantity, clearCart, selectedChild } = useChild();
  const { user } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState<'telebirr' | 'cbe' | 'card'>('telebirr');
  const [loading, setLoading] = useState(false);

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const total = subtotal;

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      clearCart();
      Alert.alert(
        'Order Placed Successfully! 🎉',
        `Thank you ${user?.name.split(' ')[0]}! Your daycare supply order of ${total} ETB has been confirmed. Supplies will be handed over to ${selectedChild?.full_name}'s lead caregiver tomorrow.`,
        [
          {
            text: 'Return to Dashboard',
            onPress: () => navigation.navigate('MainTabs'),
          },
        ]
      );
    }, 800);
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Navigation Header */}
        <View style={styles.navHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
          >
            <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
          <Text style={styles.pageTitle}>Shopping Cart</Text>
        </View>

        {/* Daycare Handover Info Banner */}
        <View style={styles.handoverBanner}>
          <ShieldCheck size={20} color={colors.statusPresentText} weight="bold" />
          <Text style={styles.handoverText}>
            Supplies ordered will be delivered directly to {selectedChild?.full_name || 'Liya'}'s room caregiver during morning check-in.
          </Text>
        </View>

        {/* Cart Items List */}
        <Text style={styles.sectionTitle}>ORDER ITEMS ({cart.length})</Text>
        {cart.length === 0 ? (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyTitle}>Your cart is empty 🛒</Text>
            <Text style={styles.emptySub}>Browse daycare store supplies and add items to your cart.</Text>
            <PillButton
              title="Explore Store"
              variant="secondary"
              onPress={() => navigation.navigate('DaycareStore')}
              style={styles.exploreBtn}
            />
          </View>
        ) : (
          <View style={styles.cartList}>
            {cart.map((item) => (
              <View key={item.product.id} style={styles.cartItemCard}>
                <View style={styles.itemMainInfo}>
                  <Text style={styles.itemName}>{item.product.name}</Text>
                  <Text style={styles.itemCategory}>{item.product.category}</Text>
                  <Text style={styles.itemPrice}>{item.product.price} ETB</Text>
                </View>

                <View style={styles.quantityControls}>
                  <TouchableOpacity
                    activeOpacity={0.7}
                    onPress={() => updateQuantity(item.product.id, item.quantity - 1)}
                    style={styles.qtyBtn}
                  >
                    <Minus size={14} color={colors.textPrimary} weight="bold" />
                  </TouchableOpacity>

                  <Text style={styles.qtyText}>{item.quantity}</Text>

                  <TouchableOpacity
                    activeOpacity={0.7}
                    onPress={() => updateQuantity(item.product.id, item.quantity + 1)}
                    style={styles.qtyBtn}
                  >
                    <Plus size={14} color={colors.textPrimary} weight="bold" />
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        )}

        {cart.length > 0 && (
          <>
            {/* Payment Options */}
            <Text style={[styles.sectionTitle, { marginTop: 24 }]}>PAYMENT METHOD</Text>
            <View style={styles.paymentOptionsContainer}>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => setPaymentMethod('telebirr')}
                style={[
                  styles.paymentOptionCard,
                  paymentMethod === 'telebirr' && styles.selectedPaymentCard,
                ]}
              >
                <View style={styles.radioDot}>
                  {paymentMethod === 'telebirr' && <View style={styles.radioDotInner} />}
                </View>
                <Text style={styles.paymentTitle}>Telebirr (Mobile Wallet)</Text>
                <Text style={styles.recommendedTag}>Fast</Text>
              </TouchableOpacity>

              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => setPaymentMethod('cbe')}
                style={[
                  styles.paymentOptionCard,
                  paymentMethod === 'cbe' && styles.selectedPaymentCard,
                ]}
              >
                <View style={styles.radioDot}>
                  {paymentMethod === 'cbe' && <View style={styles.radioDotInner} />}
                </View>
                <Text style={styles.paymentTitle}>CBE Birr / Bank Transfer</Text>
              </TouchableOpacity>

              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => setPaymentMethod('card')}
                style={[
                  styles.paymentOptionCard,
                  paymentMethod === 'card' && styles.selectedPaymentCard,
                ]}
              >
                <View style={styles.radioDot}>
                  {paymentMethod === 'card' && <View style={styles.radioDotInner} />}
                </View>
                <Text style={styles.paymentTitle}>Chapa / Visa / MasterCard</Text>
              </TouchableOpacity>
            </View>

            {/* Summary Box */}
            <Text style={[styles.sectionTitle, { marginTop: 24 }]}>ORDER SUMMARY</Text>
            <View style={styles.summaryCard}>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Subtotal</Text>
                <Text style={styles.summaryValue}>{subtotal} ETB</Text>
              </View>
              <View style={[styles.summaryRow, { marginTop: 8 }]}>
                <Text style={styles.summaryLabel}>Daycare Handover Fee</Text>
                <Text style={[styles.summaryValue, { color: colors.statusPresentText }]}>FREE</Text>
              </View>

              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Total Payable</Text>
                <Text style={styles.totalValue}>{total} ETB</Text>
              </View>
            </View>

            {/* Complete Order Button */}
            <PillButton
              title={`Complete Order (${total} ETB)`}
              showArrow
              loading={loading}
              onPress={handleCheckout}
              style={styles.checkoutBtn}
            />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  navHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  pageTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  handoverBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.statusPresentBg,
    padding: 14,
    borderRadius: radii.subcard,
    columnGap: 10,
    marginBottom: 24,
  },
  handoverText: {
    flex: 1,
    fontSize: 12.5,
    fontWeight: '600',
    color: colors.statusPresentText,
    lineHeight: 18,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 12,
  },
  emptyCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderLight,
    marginVertical: 10,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  emptySub: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 16,
  },
  exploreBtn: {
    width: 180,
  },
  cartList: {
    rowGap: 12,
  },
  cartItemCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  itemMainInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  itemCategory: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  itemPrice: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.bgNavy,
    marginTop: 6,
  },
  quantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgMuted,
    borderRadius: radii.pill,
    paddingHorizontal: 8,
    paddingVertical: 4,
    columnGap: 10,
  },
  qtyBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.bgSurface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyText: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  paymentOptionsContainer: {
    rowGap: 10,
  },
  paymentOptionCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.subcard,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 12,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  selectedPaymentCard: {
    borderColor: colors.bgNavy,
    borderWidth: 2,
    backgroundColor: colors.bgMuted,
  },
  radioDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.bgNavy,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioDotInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.bgNavy,
  },
  paymentTitle: {
    flex: 1,
    fontSize: 14.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  recommendedTag: {
    fontSize: 11,
    fontWeight: '800',
    color: colors.pastelYellowText,
    backgroundColor: colors.pastelYellow,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radii.pill,
  },
  summaryCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  summaryLabel: {
    fontSize: 13.5,
    color: colors.textSecondary,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  totalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderColor: colors.borderLight,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  totalValue: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.bgNavy,
  },
  checkoutBtn: {
    marginTop: 24,
  },
});
