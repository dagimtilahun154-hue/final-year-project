import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  User,
  Shield,
  Bell,
  Baby,
  UsersThree,
  SignOut,
  CaretRight,
  Sparkle,
  ShoppingBag,
} from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { SafetyDisclaimer } from '../../components/SafetyDisclaimer';
import { colors, radii, shadows } from '../../theme/tokens';
import { useAuth } from '../../context/AuthContext';
import { useChild } from '../../context/ChildContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type ProfileScreenProps = {
  navigation?: any;
};

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ navigation }) => {
  const { user, logout } = useAuth();
  const { selectedChild } = useChild();

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out of Ankelba Parent App?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: () => logout() },
    ]);
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Card Header */}
        <View style={styles.parentProfileCard}>
          <View style={styles.avatarCircle}>
            <Text style={styles.avatarText}>
              {user?.name
                .split(' ')
                .map((n) => n[0])
                .join('') || 'HT'}
            </Text>
          </View>
          <View style={styles.parentInfo}>
            <Text style={styles.parentName}>{user?.name || 'Hana Tesfaye'}</Text>
            <Text style={styles.parentEmail}>{user?.email || 'hana.tesfaye@example.com'}</Text>
            <Text style={styles.parentPhone}>{user?.phone || '+251 91 123 4567'}</Text>
          </View>
        </View>

        {/* Selected Child Pill Card */}
        <View style={styles.childPillCard}>
          <View style={styles.childIconBox}>
            <Baby size={20} color={colors.bgNavy} weight="bold" />
          </View>
          <View style={styles.childCardInfo}>
            <Text style={styles.childCardLabel}>ACTIVE CHILD PROFILE</Text>
            <Text style={styles.childCardName}>
              {selectedChild?.full_name || 'Liya Hana'} • {selectedChild?.group_name || 'Sunflower Group'}
            </Text>
          </View>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation?.navigate('ChildProfile')}
            style={styles.viewChildBtn}
          >
            <Text style={styles.viewChildText}>View Profile</Text>
          </TouchableOpacity>
        </View>

        {/* SECTION 1: CHILD & CARE */}
        <Text style={styles.sectionTitle}>CHILD & CARE MANAGEMENT</Text>
        <View style={styles.menuGroup}>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation?.navigate('ChildProfile')}
            style={styles.menuRow}
          >
            <View style={styles.menuIconBox}>
              <Baby size={18} color={colors.textPrimary} />
            </View>
            <Text style={styles.menuText}>Child Health & Care Profile</Text>
            <CaretRight size={16} color={colors.textMuted} weight="bold" />
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation?.navigate('AuthorizedGuardians')}
            style={[styles.menuRow, styles.rowBorder]}
          >
            <View style={styles.menuIconBox}>
              <UsersThree size={18} color={colors.textPrimary} />
            </View>
            <Text style={styles.menuText}>Authorized Pickup Guardians</Text>
            <CaretRight size={16} color={colors.textMuted} weight="bold" />
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation?.navigate('DaycareStore')}
            style={[styles.menuRow, styles.rowBorder]}
          >
            <View style={styles.menuIconBox}>
              <ShoppingBag size={18} color={colors.textPrimary} />
            </View>
            <Text style={styles.menuText}>Daycare Supply Store</Text>
            <CaretRight size={16} color={colors.textMuted} weight="bold" />
          </TouchableOpacity>
        </View>

        {/* SECTION 2: AI & ASSISTANCE */}
        <Text style={[styles.sectionTitle, { marginTop: 24 }]}>INTELLIGENT TOOLS</Text>
        <View style={styles.menuGroup}>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation?.navigate('AIGuide')}
            style={styles.menuRow}
          >
            <View style={[styles.menuIconBox, { backgroundColor: colors.pastelYellow }]}>
              <Sparkle size={18} color={colors.accentGold} weight="fill" />
            </View>
            <Text style={styles.menuText}>Ankelba AI Care Assistant</Text>
            <CaretRight size={16} color={colors.textMuted} weight="bold" />
          </TouchableOpacity>
        </View>

        {/* SECTION 3: ACCOUNT & SECURITY */}
        <Text style={[styles.sectionTitle, { marginTop: 24 }]}>ACCOUNT & SECURITY</Text>
        <View style={styles.menuGroup}>
          <TouchableOpacity activeOpacity={0.8} style={styles.menuRow}>
            <View style={styles.menuIconBox}>
              <User size={18} color={colors.textPrimary} />
            </View>
            <Text style={styles.menuText}>Edit Personal Details</Text>
            <CaretRight size={16} color={colors.textMuted} weight="bold" />
          </TouchableOpacity>

          <TouchableOpacity activeOpacity={0.8} style={[styles.menuRow, styles.rowBorder]}>
            <View style={styles.menuIconBox}>
              <Shield size={18} color={colors.textPrimary} />
            </View>
            <Text style={styles.menuText}>Password & Security</Text>
            <CaretRight size={16} color={colors.textMuted} weight="bold" />
          </TouchableOpacity>

          <TouchableOpacity activeOpacity={0.8} style={[styles.menuRow, styles.rowBorder]}>
            <View style={styles.menuIconBox}>
              <Bell size={18} color={colors.textPrimary} />
            </View>
            <Text style={styles.menuText}>Push Notifications & Alerts</Text>
            <CaretRight size={16} color={colors.textMuted} weight="bold" />
          </TouchableOpacity>
        </View>

        {/* Legal Disclaimer */}
        <SafetyDisclaimer variant="biometric" />

        {/* Sign Out Button */}
        <TouchableOpacity activeOpacity={0.8} onPress={handleLogout} style={styles.logoutBtn}>
          <SignOut size={18} color={colors.accentRed} weight="bold" />
          <Text style={styles.logoutText}>Sign Out of Ankelba</Text>
        </TouchableOpacity>

        {/* App Version */}
        <Text style={styles.versionText}>Ankelba Parent Mobile App v1.0.0 (Production Build)</Text>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 120,
  },
  parentProfileCard: {
    backgroundColor: colors.bgNavy,
    borderRadius: radii.card,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 16,
    marginTop: 10,
    marginBottom: 16,
    ...shadows.card,
  },
  avatarCircle: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.accentGold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.bgNavy,
  },
  parentInfo: {
    flex: 1,
  },
  parentName: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textWhite,
  },
  parentEmail: {
    fontSize: 12.5,
    color: colors.borderCard,
    marginTop: 2,
  },
  parentPhone: {
    fontSize: 12,
    color: colors.accentGold,
    fontWeight: '700',
    marginTop: 2,
  },
  childPillCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 12,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  childIconBox: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.pastelYellow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  childCardInfo: {
    flex: 1,
  },
  childCardLabel: {
    fontSize: 9.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.6,
  },
  childCardName: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.textPrimary,
    marginTop: 2,
  },
  viewChildBtn: {
    backgroundColor: colors.bgMuted,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radii.pill,
  },
  viewChildText: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.bgNavy,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 12,
  },
  menuGroup: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  menuRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    columnGap: 12,
  },
  rowBorder: {
    borderTopWidth: 1,
    borderColor: colors.borderLight,
  },
  menuIconBox: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.bgSurface,
    paddingVertical: 14,
    borderRadius: radii.card,
    columnGap: 8,
    marginTop: 16,
    borderWidth: 1,
    borderColor: colors.pastelPinkText,
  },
  logoutText: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.accentRed,
  },
  versionText: {
    fontSize: 11.5,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: 20,
  },
});
