import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, User, Phone, EnvelopeSimple, ShieldCheck, Camera } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { PillButton } from '../../components/PillButton';
import { SafetyDisclaimer } from '../../components/SafetyDisclaimer';
import { colors, radii, shadows } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type AddGuardianProps = {
  navigation: StackNavigationProp<RootStackParamList, 'AddGuardian'>;
};

const RELATIONSHIPS = ['Grandparent', 'Uncle', 'Aunt', 'Family Friend', 'Nanny / Caretaker'];

export const AddGuardianScreen: React.FC<AddGuardianProps> = ({ navigation }) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [relationship, setRelationship] = useState('Grandparent');
  const [canPickup, setCanPickup] = useState(true);
  const [isBiometricEnrolled, setIsBiometricEnrolled] = useState(false);

  const handleSubmitGuardian = () => {
    if (!fullName.trim() || !phone.trim()) {
      Alert.alert('Missing Fields', 'Please enter full name and phone number for the guardian.');
      return;
    }

    Alert.alert(
      'Guardian Enrolled',
      `${fullName} has been registered as an authorized pickup guardian for Liya.`,
      [
        {
          text: 'OK',
          onPress: () => navigation.goBack(),
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Nav Header */}
        <View style={styles.navHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
          >
            <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
          <View>
            <Text style={styles.headerTitle}>Add Pickup Guardian</Text>
            <Text style={styles.headerSubtitle}>Authorize an adult family member or caretaker</Text>
          </View>
        </View>

        {/* Biometric & Safety Disclaimer */}
        <SafetyDisclaimer variant="biometric" />

        {/* Form Container */}
        <View style={styles.formCard}>
          {/* Full Name */}
          <Text style={styles.fieldLabel}>GUARDIAN FULL NAME *</Text>
          <View style={styles.inputWrapper}>
            <User size={18} color={colors.textSecondary} />
            <TextInput
              style={styles.input}
              placeholder="e.g. Solomon Haile"
              placeholderTextColor={colors.textMuted}
              value={fullName}
              onChangeText={setFullName}
            />
          </View>

          {/* Phone Number */}
          <Text style={styles.fieldLabel}>PHONE NUMBER *</Text>
          <View style={styles.inputWrapper}>
            <Phone size={18} color={colors.textSecondary} />
            <TextInput
              style={styles.input}
              placeholder="+251 91 876 5432"
              placeholderTextColor={colors.textMuted}
              keyboardType="phone-pad"
              value={phone}
              onChangeText={setPhone}
            />
          </View>

          {/* Email Address */}
          <Text style={styles.fieldLabel}>EMAIL ADDRESS (OPTIONAL)</Text>
          <View style={styles.inputWrapper}>
            <EnvelopeSimple size={18} color={colors.textSecondary} />
            <TextInput
              style={styles.input}
              placeholder="solomon@example.com"
              placeholderTextColor={colors.textMuted}
              keyboardType="email-address"
              value={email}
              onChangeText={setEmail}
            />
          </View>

          {/* Relationship Chips */}
          <Text style={styles.fieldLabel}>RELATIONSHIP TO CHILD</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.relRow}
          >
            {RELATIONSHIPS.map((rel) => (
              <TouchableOpacity
                key={rel}
                activeOpacity={0.8}
                onPress={() => setRelationship(rel)}
                style={[styles.relChip, relationship === rel && styles.selectedRelChip]}
              >
                <Text style={[styles.relText, relationship === rel && styles.selectedRelText]}>
                  {rel}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Photo Verification Upload */}
          <Text style={styles.fieldLabel}>ID DOCUMENT / PHOTO VERIFICATION</Text>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => Alert.alert('Upload Photo', 'Photo verification preview attached.')}
            style={styles.uploadCard}
          >
            <Camera size={24} color={colors.bgNavy} weight="bold" />
            <View>
              <Text style={styles.uploadTitle}>Upload Guardian Photo / ID</Text>
              <Text style={styles.uploadSub}>Required for visual identity check at pickup</Text>
            </View>
          </TouchableOpacity>

          {/* Pickup Permission Toggle */}
          <View style={styles.toggleRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.toggleTitle}>Authorize Child Pickup</Text>
              <Text style={styles.toggleSub}>Allow daycare staff to hand over child to this person</Text>
            </View>
            <Switch
              value={canPickup}
              onValueChange={setCanPickup}
              trackColor={{ false: colors.borderLight, true: colors.bgNavy }}
              thumbColor={colors.textWhite}
            />
          </View>

          {/* Biometric Verification Enable */}
          <View style={[styles.toggleRow, styles.rowBorder]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.toggleTitle}>Enable Biometric Verification</Text>
              <Text style={styles.toggleSub}>Allow fingerprint / facial scan verification at gate</Text>
            </View>
            <Switch
              value={isBiometricEnrolled}
              onValueChange={setIsBiometricEnrolled}
              trackColor={{ false: colors.borderLight, true: colors.accentGold }}
              thumbColor={colors.textWhite}
            />
          </View>
        </View>

        {/* Submit Action Button */}
        <PillButton
          title="Register Guardian"
          onPress={handleSubmitGuardian}
          style={styles.submitBtn}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  navHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
    columnGap: 12,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  headerSubtitle: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 1,
  },
  formCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    rowGap: 14,
    marginBottom: 20,
    ...shadows.card,
  },
  fieldLabel: {
    fontSize: 10.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
  },
  inputWrapper: {
    height: 48,
    backgroundColor: colors.bgInput,
    borderRadius: radii.input,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    columnGap: 10,
  },
  input: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  relRow: {
    columnGap: 8,
    paddingVertical: 4,
  },
  relChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: radii.pill,
    backgroundColor: colors.bgMuted,
  },
  selectedRelChip: {
    backgroundColor: colors.bgNavy,
  },
  relText: {
    fontSize: 12.5,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  selectedRelText: {
    color: colors.textWhite,
    fontWeight: '700',
  },
  uploadCard: {
    backgroundColor: colors.pastelYellow,
    borderRadius: radii.card,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 12,
  },
  uploadTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  uploadSub: {
    fontSize: 11,
    color: colors.textSecondary,
    marginTop: 1,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 10,
  },
  rowBorder: {
    borderTopWidth: 1,
    borderColor: colors.borderLight,
    paddingTop: 14,
  },
  toggleTitle: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  toggleSub: {
    fontSize: 11.5,
    color: colors.textSecondary,
    marginTop: 2,
  },
  submitBtn: {
    marginTop: 10,
  },
});
