import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, UserPlus, ShieldCheck, Phone } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { SafetyDisclaimer } from '../../components/SafetyDisclaimer';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type AuthorizedGuardiansProps = {
  navigation: StackNavigationProp<RootStackParamList, 'AuthorizedGuardians'>;
};

const GUARDIANS_LIST = [
  {
    id: 1,
    name: 'Hana Tesfaye',
    relation: 'Mother (Primary Guardian)',
    phone: '+251 91 123 4567',
    status: 'Verified & Active',
    initials: 'HT',
  },
  {
    id: 2,
    name: 'Abebe Hana',
    relation: 'Father (Authorized Pickup)',
    phone: '+251 91 987 6543',
    status: 'Verified & Active',
    initials: 'AH',
  },
  {
    id: 3,
    name: 'Tigist Tesfaye',
    relation: 'Aunt (Emergency Pickup)',
    phone: '+251 92 333 4455',
    status: 'Verified & Active',
    initials: 'TT',
  },
];

export const AuthorizedGuardiansScreen: React.FC<AuthorizedGuardiansProps> = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Navigation Header */}
        <View style={styles.navHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
          >
            <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
          <View>
            <Text style={styles.pageTitle}>Authorized Pickups</Text>
            <Text style={styles.pageSubtitle}>Adult guardians verified for child pickup</Text>
          </View>
        </View>

        {/* Child Safety Disclaimer Banner */}
        <SafetyDisclaimer variant="biometric" />

        {/* Guardians List */}
        <Text style={styles.sectionTitle}>VERIFIED PICKUP GUARDIANS</Text>
        <View style={styles.listContainer}>
          {GUARDIANS_LIST.map((guardian) => (
            <View key={guardian.id} style={styles.guardianCard}>
              <View style={styles.cardHeader}>
                <View style={styles.avatarCircle}>
                  <Text style={styles.avatarText}>{guardian.initials}</Text>
                </View>
                <View style={styles.guardianDetails}>
                  <Text style={styles.guardianName}>{guardian.name}</Text>
                  <Text style={styles.guardianRelation}>{guardian.relation}</Text>
                  <View style={styles.phoneRow}>
                    <Phone size={13} color={colors.textSecondary} />
                    <Text style={styles.phoneText}>{guardian.phone}</Text>
                  </View>
                </View>
              </View>

              <View style={styles.cardFooter}>
                <View style={styles.statusBadge}>
                  <ShieldCheck size={14} color={colors.statusPresentText} weight="bold" />
                  <Text style={styles.statusText}>{guardian.status}</Text>
                </View>
                <TouchableOpacity activeOpacity={0.7}>
                  <Text style={styles.editText}>Edit</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>

        {/* Add Guardian Button */}
        <PillButton
          title="Add Authorized Guardian"
          leftIcon={<UserPlus size={18} color={colors.textWhite} weight="bold" />}
          onPress={() => {}}
          style={styles.addBtn}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  navHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  pageTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  pageSubtitle: {
    fontSize: 12.5,
    color: colors.textSecondary,
    marginTop: 2,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginTop: 14,
    marginBottom: 12,
  },
  listContainer: {
    rowGap: 14,
    marginBottom: 24,
  },
  guardianCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 14,
  },
  avatarCircle: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.bgNavy,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.textWhite,
  },
  guardianDetails: {
    flex: 1,
  },
  guardianName: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  guardianRelation: {
    fontSize: 12.5,
    color: colors.textSecondary,
    marginTop: 2,
  },
  phoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 6,
    marginTop: 4,
  },
  phoneText: {
    fontSize: 12,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 14,
    paddingTop: 10,
    borderTopWidth: 1,
    borderColor: colors.borderLight,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.statusPresentBg,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radii.pill,
    columnGap: 6,
  },
  statusText: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.statusPresentText,
  },
  editText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.bgNavy,
  },
  addBtn: {
    marginTop: 4,
  },
});
