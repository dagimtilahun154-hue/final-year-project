import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, UsersThree } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { StatusBadge } from '../../components/StatusBadge';
import { SafetyDisclaimer } from '../../components/SafetyDisclaimer';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { useChild } from '../../context/ChildContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type ChildProfileProps = {
  navigation: StackNavigationProp<RootStackParamList, 'ChildProfile'>;
};

export const ChildProfileScreen: React.FC<ChildProfileProps> = ({ navigation }) => {
  const { selectedChild } = useChild();

  const handleManageGuardians = () => {
    navigation.navigate('AuthorizedGuardians');
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Navigation Back Bar */}
        <View style={styles.navHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
          >
            <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
          <Text style={styles.pageTitle}>Child Profile</Text>
        </View>

        {/* Profile Card Header */}
        <View style={styles.profileHeaderCard}>
          <View style={styles.avatarCircle}>
            <Text style={styles.avatarText}>LH</Text>
          </View>
          <View style={styles.childHeaderInfo}>
            <Text style={styles.childName}>{selectedChild?.full_name || 'Liya Hana'}</Text>
            <Text style={styles.childMeta}>4 years old • {selectedChild?.group_name || 'Sunflower Group'}</Text>
          </View>
          <StatusBadge status="at_daycare" />
        </View>

        {/* Basic Information Card */}
        <Text style={styles.sectionTitle}>BASIC INFORMATION</Text>
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Date of Birth</Text>
            <Text style={styles.infoValue}>May 12, 2020</Text>
          </View>
          <View style={[styles.infoRow, styles.rowBorder]}>
            <Text style={styles.infoLabel}>Gender</Text>
            <Text style={styles.infoValue}>Female</Text>
          </View>
          <View style={[styles.infoRow, styles.rowBorder]}>
            <Text style={styles.infoLabel}>Languages</Text>
            <Text style={styles.infoValue}>Amharic, English</Text>
          </View>
          <View style={[styles.infoRow, styles.rowBorder, { flexDirection: 'column', alignItems: 'flex-start', rowGap: 8 }]}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%' }}>
              <Text style={styles.infoLabel}>Attendance Rate</Text>
              <Text style={[styles.infoValue, { color: colors.statusPresentText }]}>92% (Excellent)</Text>
            </View>
            <View style={styles.progressBarBg}>
              <View style={[styles.progressBarFill, { width: '92%' }]} />
            </View>
          </View>
        </View>

        {/* Care & Safety Card */}
        <Text style={[styles.sectionTitle, { marginTop: 24 }]}>CARE & SAFETY INSTRUCTIONS</Text>
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Assigned Caregiver</Text>
            <Text style={styles.infoValue}>Sara Mekonnen</Text>
          </View>
          <View style={[styles.infoRow, styles.rowBorder]}>
            <Text style={styles.infoLabel}>Meal Preference</Text>
            <Text style={styles.infoValue}>Mild Ethiopian food, Injera</Text>
          </View>
          <View style={[styles.infoRow, styles.rowBorder, { flexDirection: 'column', alignItems: 'flex-start', rowGap: 4 }]}>
            <Text style={styles.infoLabel}>Special Instructions</Text>
            <Text style={styles.infoBody}>Prefers afternoon rest with soft music; highly engaged during story reading sessions.</Text>
          </View>
        </View>

        {/* Legal Disclaimer */}
        <SafetyDisclaimer variant="biometric" />

        {/* Family & Pickup Guardians */}
        <Text style={[styles.sectionTitle, { marginTop: 14 }]}>FAMILY & AUTHORIZED PICKUPS</Text>
        <View style={styles.infoCard}>
          <View style={styles.guardianRow}>
            <View style={styles.guardianAvatar}>
              <Text style={styles.guardianAvatarText}>HT</Text>
            </View>
            <View style={styles.guardianInfo}>
              <Text style={styles.guardianName}>Hana Tesfaye</Text>
              <Text style={styles.guardianRole}>Mother • Primary Contact</Text>
            </View>
            <Text style={styles.verifiedTag}>✓ Auth</Text>
          </View>

          <View style={[styles.guardianRow, styles.rowBorder]}>
            <View style={styles.guardianAvatar}>
              <Text style={styles.guardianAvatarText}>AH</Text>
            </View>
            <View style={styles.guardianInfo}>
              <Text style={styles.guardianName}>Abebe Hana</Text>
              <Text style={styles.guardianRole}>Father • Authorized Pickup</Text>
            </View>
            <Text style={styles.verifiedTag}>✓ Auth</Text>
          </View>

          <PillButton
            title="View All Authorized Pickups"
            variant="secondary"
            leftIcon={<UsersThree size={18} color={colors.textPrimary} weight="bold" />}
            onPress={handleManageGuardians}
            style={styles.manageGuardiansBtn}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  navHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  pageTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  profileHeaderCard: {
    backgroundColor: colors.bgNavy,
    borderRadius: radii.card,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 14,
    marginBottom: 24,
    ...shadows.card,
  },
  avatarCircle: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: colors.accentGold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.bgNavy,
  },
  childHeaderInfo: {
    flex: 1,
  },
  childName: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textWhite,
  },
  childMeta: {
    fontSize: 12.5,
    color: colors.borderCard,
    marginTop: 2,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 12,
  },
  infoCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  rowBorder: {
    borderTopWidth: 1,
    borderColor: colors.borderLight,
  },
  infoLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  infoBody: {
    fontSize: 13,
    color: colors.textPrimary,
    lineHeight: 19,
    marginTop: 2,
  },
  progressBarBg: {
    width: '100%',
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.bgMuted,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: colors.statusPresentText,
    borderRadius: 4,
  },
  guardianRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    columnGap: 12,
  },
  guardianAvatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  guardianAvatarText: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  guardianInfo: {
    flex: 1,
  },
  guardianName: {
    fontSize: 14.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  guardianRole: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  verifiedTag: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.statusPresentText,
    backgroundColor: colors.statusPresentBg,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radii.pill,
  },
  manageGuardiansBtn: {
    marginTop: 12,
  },
});
