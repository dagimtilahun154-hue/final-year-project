import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, ShieldCheck, QrCode, Clock, Baby, User, Sparkle } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { SafetyDisclaimer } from '../../components/SafetyDisclaimer';
import { colors, radii, shadows } from '../../theme/tokens';
import { useChild } from '../../context/ChildContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type PickupVerificationProps = {
  navigation: StackNavigationProp<RootStackParamList, 'PickupVerification'>;
};

export const PickupVerificationScreen: React.FC<PickupVerificationProps> = ({ navigation }) => {
  const { selectedChild } = useChild();
  const [secondsRemaining, setSecondsRemaining] = useState(2700); // 45 minutes

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Nav Header */}
        <View style={styles.navHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
          >
            <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
          <View>
            <View style={styles.titleRow}>
              <Text style={styles.headerTitle}>Pickup Pass</Text>
              <ShieldCheck size={20} color={colors.statusPresentText} weight="fill" />
            </View>
            <Text style={styles.headerSubtitle}>Verified Daycare Gate Identity Pass</Text>
          </View>
        </View>

        {/* Biometric Privacy Disclaimer */}
        <SafetyDisclaimer variant="biometric" />

        {/* Active Child & Guardian Card */}
        <View style={styles.childHeaderCard}>
          <View style={styles.childBadgeIcon}>
            <Baby size={24} color={colors.bgNavy} weight="bold" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.childBadgeLabel}>CHILD TO PICKUP</Text>
            <Text style={styles.childBadgeName}>
              {selectedChild?.full_name || 'Liya Hana'} • {selectedChild?.group_name || 'Sunflower Group'}
            </Text>
            <Text style={styles.guardianSubText}>Authorized Guardian: Hana Tesfaye (Mother)</Text>
          </View>
        </View>

        {/* Dynamic QR Code & Passcode Security Card */}
        <View style={styles.passCard}>
          <View style={styles.passHeader}>
            <Sparkle size={16} color={colors.accentGold} weight="fill" />
            <Text style={styles.passHeaderTitle}>LIVE GATE VERIFICATION CODE</Text>
          </View>

          {/* QR Code Visual Box */}
          <View style={styles.qrContainer}>
            <View style={styles.qrBox}>
              <QrCode size={160} color={colors.bgNavy} weight="bold" />
            </View>
            <Text style={styles.qrInstructions}>
              Show this QR code to daycare security scanner at pickup gate
            </Text>
          </View>

          {/* Backup Passcode */}
          <View style={styles.codeBox}>
            <Text style={styles.codeLabel}>MANUAL FALLBACK PASSCODE</Text>
            <Text style={styles.codeDigits}>849 201</Text>
          </View>

          {/* Countdown Expiry Timer */}
          <View style={styles.timerRow}>
            <Clock size={16} color={colors.accentGold} weight="bold" />
            <Text style={styles.timerText}>
              Pass Expires In: <Text style={styles.timerHighlight}>{formatTime(secondsRemaining)}</Text>
            </Text>
          </View>
        </View>

        {/* Biometric Verification Method Tag */}
        <View style={styles.biometricMethodCard}>
          <ShieldCheck size={22} color={colors.statusPresentText} weight="bold" />
          <View style={{ flex: 1 }}>
            <Text style={styles.methodTitle}>Biometric Verification Ready</Text>
            <Text style={styles.methodSub}>
              Guardian fingerprint enrolled for instant automated gate release
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  navHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
    columnGap: 12,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 6,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  headerSubtitle: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 1,
  },
  childHeaderCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 14,
    borderWidth: 1,
    borderColor: colors.borderLight,
    marginBottom: 20,
    ...shadows.card,
  },
  childBadgeIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.pastelYellow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  childBadgeLabel: {
    fontSize: 9.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.6,
  },
  childBadgeName: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.textPrimary,
    marginTop: 1,
  },
  guardianSubText: {
    fontSize: 11.5,
    color: colors.textSecondary,
    marginTop: 2,
  },
  passCard: {
    backgroundColor: colors.bgNavy,
    borderRadius: radii.card,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
    ...shadows.card,
  },
  passHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 6,
    marginBottom: 16,
  },
  passHeaderTitle: {
    fontSize: 10.5,
    fontWeight: '800',
    color: colors.accentGold,
    letterSpacing: 0.8,
  },
  qrContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  qrBox: {
    backgroundColor: colors.textWhite,
    padding: 16,
    borderRadius: radii.card,
    ...shadows.card,
  },
  qrInstructions: {
    fontSize: 11.5,
    color: colors.borderCard,
    textAlign: 'center',
    marginTop: 12,
    maxWidth: 220,
  },
  codeBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: radii.input,
    paddingHorizontal: 24,
    paddingVertical: 10,
    alignItems: 'center',
    width: '100%',
    marginBottom: 16,
  },
  codeLabel: {
    fontSize: 9,
    fontWeight: '800',
    color: colors.accentGold,
    letterSpacing: 0.8,
  },
  codeDigits: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.textWhite,
    letterSpacing: 4,
    marginTop: 2,
  },
  timerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 6,
  },
  timerText: {
    fontSize: 12,
    color: colors.textWhite,
  },
  timerHighlight: {
    fontWeight: '800',
    color: colors.accentGold,
  },
  biometricMethodCard: {
    backgroundColor: colors.statusPresentBg,
    borderRadius: radii.card,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 12,
  },
  methodTitle: {
    fontSize: 13.5,
    fontWeight: '800',
    color: colors.statusPresentText,
  },
  methodSub: {
    fontSize: 11.5,
    color: colors.textPrimary,
    marginTop: 2,
  },
});
