import { NavigatorScreenParams } from '@react-navigation/native';
import { MainTabParamList } from './MainTabNavigator';

export type RootStackParamList = {
  // Auth & Onboarding Flow
  Splash: undefined;
  Onboarding: undefined;
  Login: undefined;
  ForgotPassword: undefined;
  OTP: { email?: string };

  // Main 5-Tab Shell
  MainTabs: NavigatorScreenParams<MainTabParamList>;

  // Activity & Reports
  FullDailyReport: { reportId?: number; childId?: number };
  ChildProfile: { childId?: number };

  // AI Parent Guide
  AskAnkelba: { childId?: number };

  // Guardians & Biometrics
  AuthorizedGuardians: { childId?: number };
  AddGuardian: { childId?: number };
  PickupStatus: { childId?: number; guardianId?: number };

  // Store & Payments
  StoreCatalog: undefined;
  ShoppingCart: undefined;
  Checkout: undefined;
  PaymentSuccess: { orderId?: number };

  // Messages & Events
  ChatDetail: { threadId?: number; caregiverName?: string };
  EventDetail: { eventId?: number };
};
