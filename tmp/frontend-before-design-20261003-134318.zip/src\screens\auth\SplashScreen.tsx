import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Rect, Path, G, Defs, Filter, FeFlood, FeColorMatrix, FeGaussianBlur, FeComposite, FeBlend, ClipPath, Image as SvgImage, Pattern, Use } from 'react-native-svg';
import { ArrowRight } from 'phosphor-react-native';
import { colors, radii } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

const { width } = Dimensions.get('window');

type SplashScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'Splash'>;
};

export const SplashScreen: React.FC<SplashScreenProps> = ({ navigation }) => {
  const handleGetStarted = () => {
    navigation.navigate('Onboarding');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollContent} bounces={false}>
        {/* Top Decorative Vector Header matching SVG */}
        <View style={styles.headerContainer}>
          <Svg width={width} height={420} viewBox="0 0 390 436" fill="none">
            <Defs>
              <ClipPath id="clip0">
                <Rect width="390" height="436" fill="#FFFBEB" />
              </ClipPath>
              <ClipPath id="clip1">
                <Rect width="128" height="128" fill="white" transform="translate(326 -64)" />
              </ClipPath>
              <ClipPath id="clip2">
                <Rect width="96" height="192" fill="white" transform="translate(-48 180)" />
              </ClipPath>
              <ClipPath id="clip3">
                <Rect width="64" height="64" fill="white" transform="translate(347.33 145.33)" />
              </ClipPath>
            </Defs>

            <G clipPath="url(#clip0)">
              <Rect width="390" height="436" fill="#FFFBEB" />
              <G opacity={0.4} clipPath="url(#clip1)">
                <Path d="M326 64C326 -6.64512 383.355 -64 454 -64V64H326Z" fill="#FFDF9F" />
              </G>
              <G opacity={0.3} clipPath="url(#clip2)">
                <Path d="M48 180C-4.98384 180 -48 223.016 -48 276C-48 328.984 -4.98384 372 48 372V180Z" fill="#FFDCBE" />
              </G>
              <G opacity={0.5}>
                <Rect x="32" y="96" width="12" height="12" rx="6" fill="#D2E4FF" />
                <Rect x="52" y="112" width="12" height="12" rx="6" fill="#F9BD22" />
              </G>
              <G opacity={0.4} clipPath="url(#clip3)">
                <Path d="M347.33 177.33C347.33 194.991 361.669 209.33 379.33 209.33C396.991 209.33 411.33 194.991 411.33 177.33C411.33 159.669 396.991 145.33 379.33 145.33C361.669 145.33 347.33 159.669 347.33 177.33Z" fill="#FFDAD6" />
              </G>
              <Rect x="25.985" y="95" width="360" height="270" rx="72" fill="#D2E4FF" opacity={0.25} />
            </G>
          </Svg>

          {/* Centered Brand Illustration Card */}
          <View style={styles.heroBadgeOverlay}>
            <View style={styles.illustrationCircle}>
              <Text style={styles.badgeEmoji}>👶</Text>
              <Text style={styles.badgeSubEmoji}>☀️</Text>
            </View>
          </View>
        </View>

        {/* Content Body Section */}
        <View style={styles.bodyContainer}>
          {/* Ankelba Vector Wordmark Title */}
          <Text style={styles.brandTitle}>Ankelba</Text>

          <Text style={styles.subtitle}>
            Daycare parent communication and child activity reporting system
          </Text>

          {/* Indicator Dots */}
          <View style={styles.indicatorContainer}>
            <View style={[styles.dot, { backgroundColor: '#FFDAD6' }]} />
            <View style={[styles.dot, styles.activeDot, { backgroundColor: '#FFC329' }]} />
            <View style={[styles.dot, { backgroundColor: '#B0C8EB' }]} />
          </View>

          {/* CTA Pill Button */}
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={handleGetStarted}
            style={styles.ctaButton}
          >
            <Text style={styles.ctaText}>Get Started</Text>
            <ArrowRight size={20} color="#FFFFFF" weight="bold" />
          </TouchableOpacity>

          {/* Footer Tagline */}
          <Text style={styles.footerTagline}>CONNECT • NURTURE • GROW</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFDF9',
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'space-between',
    paddingBottom: 32,
  },
  headerContainer: {
    width: '100%',
    height: 400,
    backgroundColor: '#FFFBEB',
    borderBottomLeftRadius: 36,
    borderBottomRightRadius: 36,
    position: 'relative',
    overflow: 'hidden',
  },
  heroBadgeOverlay: {
    position: 'absolute',
    top: 110,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  illustrationCircle: {
    width: 170,
    height: 170,
    borderRadius: 85,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 4,
    borderColor: '#FEF5D1',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 4,
  },
  badgeEmoji: {
    fontSize: 72,
  },
  badgeSubEmoji: {
    fontSize: 24,
    position: 'absolute',
    bottom: 20,
    right: 25,
  },
  bodyContainer: {
    paddingHorizontal: 28,
    alignItems: 'center',
    paddingTop: 24,
  },
  brandTitle: {
    fontSize: 36,
    fontWeight: '800',
    color: '#43474D',
    letterSpacing: -0.5,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14.5,
    color: '#74777E',
    textAlign: 'center',
    lineHeight: 22,
    fontWeight: '400',
    marginBottom: 28,
  },
  indicatorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 10,
    marginBottom: 32,
  },
  dot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  activeDot: {
    width: 28,
  },
  ctaButton: {
    width: '100%',
    height: 60,
    backgroundColor: '#000F22',
    borderRadius: 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    columnGap: 10,
    shadowColor: '#000F22',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 4,
    marginBottom: 20,
  },
  ctaText: {
    fontSize: 16.5,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  footerTagline: {
    fontSize: 11,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 1.5,
  },
});
