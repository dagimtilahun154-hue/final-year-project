import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ShoppingBag, MagnifyingGlass, Plus, Check } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { useChild } from '../../context/ChildContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type StoreScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'DaycareStore'>;
};

const CATEGORIES = ['All Products', 'Diapers & Wipes', 'Bedding', 'Art Supplies', 'Apparel'];

const PRODUCTS = [
  {
    id: 101,
    name: 'Soft Organic Cotton Apron',
    category: 'Apparel',
    price: 450,
    unit: '1 Set',
    bgColor: colors.pastelYellow,
    textColor: colors.pastelYellowText,
  },
  {
    id: 102,
    name: 'Eco Diaper Wipes Pack (3x)',
    category: 'Diapers & Wipes',
    price: 620,
    unit: '3 Packs',
    bgColor: colors.pastelCyan,
    textColor: colors.pastelCyanText,
  },
  {
    id: 103,
    name: 'Sunflower Nap Bedding Set',
    category: 'Bedding',
    price: 1200,
    unit: '1 Set',
    bgColor: colors.pastelPurple,
    textColor: colors.pastelPurpleText,
  },
  {
    id: 104,
    name: 'Non-Toxic Water Colors',
    category: 'Art Supplies',
    price: 350,
    unit: '1 Box',
    bgColor: colors.pastelPeach,
    textColor: colors.pastelPeachText,
  },
];

export const DaycareStoreScreen: React.FC<StoreScreenProps> = ({ navigation }) => {
  const { cart, addToCart } = useChild();
  const [selectedCategory, setSelectedCategory] = useState('All Products');
  const [searchQuery, setSearchQuery] = useState('');

  const cartTotalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotalPrice = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const handleAddToCart = (product: typeof PRODUCTS[0]) => {
    addToCart({
      id: product.id,
      name: product.name,
      category: product.category,
      price: product.price,
      in_stock: true,
    });
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header Row */}
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.title}>Daycare Supply Store</Text>
            <Text style={styles.subtitle}>Order official daycare supplies & personal care items</Text>
          </View>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation.navigate('ShoppingCart')}
            style={styles.cartIconBtn}
          >
            <ShoppingBag size={22} color={colors.bgNavy} weight="bold" />
            {cartTotalCount > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>{cartTotalCount}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchWrapper}>
          <MagnifyingGlass size={18} color={colors.textSecondary} weight="bold" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search products..."
            placeholderTextColor={colors.textMuted}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* Category Chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesRow}
        >
          {CATEGORIES.map((cat) => (
            <TouchableOpacity
              key={cat}
              activeOpacity={0.8}
              onPress={() => setSelectedCategory(cat)}
              style={[
                styles.categoryChip,
                selectedCategory === cat && styles.selectedCategoryChip,
              ]}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedCategory === cat && styles.selectedCategoryText,
                ]}
              >
                {cat}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Product Cards Grid */}
        <Text style={styles.sectionTitle}>FEATURED SUPPLIES</Text>
        <View style={styles.productsGrid}>
          {PRODUCTS.map((prod) => {
            const inCart = cart.some((c) => c.product.id === prod.id);
            return (
              <View key={prod.id} style={styles.productCard}>
                {/* Visual Product Box */}
                <View style={[styles.productBox, { backgroundColor: prod.bgColor }]}>
                  <Text style={[styles.boxCategoryTag, { color: prod.textColor }]}>
                    {prod.category}
                  </Text>
                  <Text style={styles.boxTitle}>{prod.name}</Text>
                </View>

                {/* Product Meta & Price */}
                <View style={styles.productMeta}>
                  <Text style={styles.productName}>{prod.name}</Text>
                  <Text style={styles.productUnit}>{prod.unit}</Text>
                  <Text style={styles.productPrice}>{prod.price} ETB</Text>

                  <TouchableOpacity
                    activeOpacity={0.8}
                    onPress={() => handleAddToCart(prod)}
                    style={[
                      styles.addBtn,
                      inCart && styles.addedBtn,
                    ]}
                  >
                    {inCart ? (
                      <>
                        <Check size={14} color={colors.statusPresentText} weight="bold" />
                        <Text style={styles.addedBtnText}>In Cart</Text>
                      </>
                    ) : (
                      <>
                        <Plus size={14} color={colors.textWhite} weight="bold" />
                        <Text style={styles.addBtnText}>Add</Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              </View>
            );
          })}
        </View>

        {/* Floating Cart Banner Button */}
        {cartTotalCount > 0 && (
          <PillButton
            title={`View Cart (${cartTotalCount} items • ${cartTotalPrice} ETB)`}
            showArrow
            onPress={() => navigation.navigate('ShoppingCart')}
            style={styles.floatingCartBtn}
          />
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  headerRow: {
    marginTop: 10,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  subtitle: {
    fontSize: 12.5,
    color: colors.textSecondary,
    marginTop: 2,
  },
  cartIconBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.bgSurface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.borderLight,
    position: 'relative',
    ...shadows.card,
  },
  cartBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.accentRed,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cartBadgeText: {
    fontSize: 10.5,
    fontWeight: '800',
    color: colors.textWhite,
  },
  searchWrapper: {
    height: 48,
    backgroundColor: colors.bgInput,
    borderRadius: radii.input,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    columnGap: 10,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  categoriesRow: {
    columnGap: 8,
    paddingBottom: 20,
  },
  categoryChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: radii.pill,
    backgroundColor: colors.bgSurface,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  selectedCategoryChip: {
    backgroundColor: colors.bgNavy,
    borderColor: colors.bgNavy,
  },
  categoryText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  selectedCategoryText: {
    color: colors.textWhite,
    fontWeight: '700',
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 14,
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    columnGap: 14,
    rowGap: 14,
  },
  productCard: {
    width: '47%',
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  productBox: {
    height: 100,
    padding: 12,
    justifyContent: 'space-between',
  },
  boxCategoryTag: {
    fontSize: 9.5,
    fontWeight: '800',
    letterSpacing: 0.6,
  },
  boxTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  productMeta: {
    padding: 12,
  },
  productName: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  productUnit: {
    fontSize: 11.5,
    color: colors.textSecondary,
    marginTop: 2,
  },
  productPrice: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.bgNavy,
    marginTop: 6,
    marginBottom: 10,
  },
  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.bgNavy,
    paddingVertical: 8,
    borderRadius: radii.pill,
    columnGap: 4,
  },
  addedBtn: {
    backgroundColor: colors.statusPresentBg,
  },
  addBtnText: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.textWhite,
  },
  addedBtnText: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.statusPresentText,
  },
  floatingCartBtn: {
    marginTop: 24,
  },
});
