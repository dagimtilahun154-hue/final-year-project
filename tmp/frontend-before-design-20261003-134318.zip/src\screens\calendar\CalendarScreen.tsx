import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CalendarBlank, MapPin, Clock, CaretDown, Check } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { colors, radii, shadows } from '../../theme/tokens';

const DAYS_STRIP = [
  { dayName: 'MON', dateNum: '24' },
  { dayName: 'TUE', dateNum: '25', active: true },
  { dayName: 'WED', dateNum: '26' },
  { dayName: 'THU', dateNum: '27' },
  { dayName: 'FRI', dateNum: '28' },
];

const EVENTS_LIST = [
  {
    id: 1,
    month: 'AUG',
    day: '28',
    title: 'Parent-Teacher Progress Meeting',
    time: '4:00 PM - 5:30 PM',
    location: 'Room 3 • Sunflower Group',
    description: 'Individual parent-caregiver progress reviews and autumn term developmental goal updates.',
    rsvp: true,
  },
  {
    id: 2,
    month: 'SEP',
    day: '02',
    title: 'Cultural Heritage Day & Parade',
    time: '10:00 AM - 1:00 PM',
    location: 'Main Daycare Courtyard',
    description: 'Children celebrate traditional Ethiopian culture with traditional clothes and storytelling.',
    rsvp: false,
  },
  {
    id: 3,
    month: 'SEP',
    day: '11',
    title: 'Enkutatash (Ethiopian New Year)',
    time: 'All Day',
    location: 'Daycare Closed',
    description: 'Daycare closed for national public holiday celebration.',
    rsvp: false,
    closed: true,
  },
];

export const CalendarScreen: React.FC = () => {
  const [selectedDay, setSelectedDay] = useState('25');
  const [rsvps, setRsvps] = useState<Record<number, boolean>>({ 1: true });

  const toggleRsvp = (eventId: number) => {
    setRsvps((prev) => ({ ...prev, [eventId]: !prev[eventId] }));
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Title & Month Selector */}
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.title}>Daycare Events Calendar</Text>
            <Text style={styles.subtitle}>Upcoming meetings, celebrations & holidays</Text>
          </View>
          <TouchableOpacity activeOpacity={0.8} style={styles.monthPill}>
            <Text style={styles.monthText}>August 2026</Text>
            <CaretDown size={14} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
        </View>

        {/* Horizontal Days Strip */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.daysStrip}
        >
          {DAYS_STRIP.map((item) => {
            const isSelected = selectedDay === item.dateNum;
            return (
              <TouchableOpacity
                key={item.dateNum}
                activeOpacity={0.8}
                onPress={() => setSelectedDay(item.dateNum)}
                style={[
                  styles.dayCard,
                  isSelected && styles.selectedDayCard,
                ]}
              >
                <Text style={[styles.dayNameText, isSelected && styles.selectedDayName]}>
                  {item.dayName}
                </Text>
                <Text style={[styles.dateNumText, isSelected && styles.selectedDateNum]}>
                  {item.dateNum}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Events List */}
        <Text style={styles.sectionTitle}>UPCOMING EVENTS</Text>
        <View style={styles.eventsListContainer}>
          {EVENTS_LIST.map((event) => {
            const isAttending = rsvps[event.id];
            return (
              <View key={event.id} style={styles.eventCard}>
                {/* Left Date Badge */}
                <View
                  style={[
                    styles.dateBadge,
                    event.closed ? styles.closedDateBadge : styles.normalDateBadge,
                  ]}
                >
                  <Text
                    style={[
                      styles.dateMonth,
                      event.closed ? styles.closedMonthText : styles.normalMonthText,
                    ]}
                  >
                    {event.month}
                  </Text>
                  <Text
                    style={[
                      styles.dateDay,
                      event.closed ? styles.closedDayText : styles.normalDayText,
                    ]}
                  >
                    {event.day}
                  </Text>
                </View>

                {/* Event Details */}
                <View style={styles.eventBody}>
                  <Text style={styles.eventTitle}>{event.title}</Text>

                  <View style={styles.metaRow}>
                    <Clock size={13} color={colors.textSecondary} />
                    <Text style={styles.metaText}>{event.time}</Text>
                    <MapPin size={13} color={colors.textSecondary} style={{ marginLeft: 6 }} />
                    <Text style={styles.metaText}>{event.location}</Text>
                  </View>

                  <Text style={styles.eventDescription}>{event.description}</Text>

                  {!event.closed && (
                    <TouchableOpacity
                      activeOpacity={0.8}
                      onPress={() => toggleRsvp(event.id)}
                      style={[
                        styles.rsvpBtn,
                        isAttending ? styles.rsvpAttendingBtn : styles.rsvpNormalBtn,
                      ]}
                    >
                      {isAttending && <Check size={14} color={colors.statusPresentText} weight="bold" />}
                      <Text
                        style={[
                          styles.rsvpBtnText,
                          isAttending ? styles.rsvpAttendingText : styles.rsvpNormalText,
                        ]}
                      >
                        {isAttending ? 'Attending ✓' : 'RSVP Now'}
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  headerRow: {
    marginTop: 10,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  subtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    marginTop: 2,
  },
  monthPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgMuted,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radii.pill,
    columnGap: 6,
  },
  monthText: {
    fontSize: 12.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  daysStrip: {
    columnGap: 10,
    marginBottom: 24,
  },
  dayCard: {
    width: 58,
    height: 68,
    borderRadius: radii.card,
    backgroundColor: colors.bgSurface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  selectedDayCard: {
    backgroundColor: colors.bgNavy,
    borderColor: colors.bgNavy,
  },
  dayNameText: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.textMuted,
  },
  selectedDayName: {
    color: colors.borderCard,
  },
  dateNumText: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
    marginTop: 2,
  },
  selectedDateNum: {
    color: colors.textWhite,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 14,
  },
  eventsListContainer: {
    rowGap: 14,
  },
  eventCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    flexDirection: 'row',
    columnGap: 14,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  dateBadge: {
    width: 54,
    height: 58,
    borderRadius: radii.subcard,
    alignItems: 'center',
    justifyContent: 'center',
  },
  normalDateBadge: {
    backgroundColor: colors.pastelYellow,
  },
  closedDateBadge: {
    backgroundColor: colors.pastelPink,
  },
  dateMonth: {
    fontSize: 11,
    fontWeight: '800',
  },
  normalMonthText: {
    color: colors.pastelYellowText,
  },
  closedMonthText: {
    color: colors.pastelPinkText,
  },
  dateDay: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  normalDayText: {
    color: colors.textPrimary,
  },
  closedDayText: {
    color: colors.pastelPinkText,
  },
  eventBody: {
    flex: 1,
  },
  eventTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 4,
    marginTop: 4,
  },
  metaText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  eventDescription: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 18,
    marginTop: 8,
  },
  rsvpBtn: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radii.pill,
    columnGap: 6,
    marginTop: 12,
  },
  rsvpAttendingBtn: {
    backgroundColor: colors.statusPresentBg,
  },
  rsvpNormalBtn: {
    backgroundColor: colors.bgNavy,
  },
  rsvpBtnText: {
    fontSize: 12,
    fontWeight: '700',
  },
  rsvpAttendingText: {
    color: colors.statusPresentText,
  },
  rsvpNormalText: {
    color: colors.textWhite,
  },
});
