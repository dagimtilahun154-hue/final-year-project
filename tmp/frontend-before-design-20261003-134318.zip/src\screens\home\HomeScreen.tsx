import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  ChatCircleDots,
  ClipboardText,
  Sparkle,
  CalendarBlank,
  ArrowRight,
  Quotes,
  MapPin,
  Clock,
} from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { StatusBadge } from '../../components/StatusBadge';
import { HighlightCard } from '../../components/HighlightCard';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { useAuth } from '../../context/AuthContext';
import { useChild } from '../../context/ChildContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type HomeScreenProps = {
  navigation?: StackNavigationProp<RootStackParamList>;
};

export const HomeScreen: React.FC<HomeScreenProps> = ({ navigation }) => {
  const { user } = useAuth();
  const { selectedChild } = useChild();

  const handleNavigateReport = () => {
    navigation?.navigate('FullDailyReport', { reportId: 1 });
  };

  const handleNavigateChat = () => {
    navigation?.navigate('CaregiverChat', { threadId: 1 });
  };

  const handleNavigateAI = () => {
    navigation?.navigate('AIGuide');
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar
        onPressNotifications={() => navigation?.navigate('MainTabs')}
        onPressProfile={() => navigation?.navigate('MainTabs')}
      />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Parent Greeting Header */}
        <View style={styles.greetingHeader}>
          <Text style={styles.greetingTitle}>Good morning, {user?.name.split(' ')[0]} 👋</Text>
          <Text style={styles.greetingSub}>
            Here is {selectedChild?.full_name || 'Liya'}'s daycare update for today
          </Text>
        </View>

        {/* Child Card Banner */}
        <TouchableOpacity
          activeOpacity={0.9}
          onPress={() => navigation?.navigate('ChildProfile', { childId: selectedChild?.id })}
          style={styles.childCard}
        >
          <View style={styles.childCardHeader}>
            <View>
              <Text style={styles.childName}>{selectedChild?.full_name || 'Liya Hana'}</Text>
              <Text style={styles.childGroup}>{selectedChild?.group_name || 'Sunflower Group • 4 Years'}</Text>
            </View>
            <StatusBadge status="at_daycare" />
          </View>
          <View style={styles.checkinInfo}>
            <Text style={styles.checkinText}>Checked in today at 8:04 AM by Hana T.</Text>
          </View>
        </TouchableOpacity>

        {/* Quick Action Pills Row */}
        <Text style={styles.sectionTitle}>QUICK ACTIONS</Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.quickActionsRow}
        >
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={handleNavigateChat}
            style={styles.quickActionPill}
          >
            <ChatCircleDots size={18} color={colors.bgNavy} weight="bold" />
            <Text style={styles.quickActionLabel}>Message</Text>
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={handleNavigateReport}
            style={styles.quickActionPill}
          >
            <ClipboardText size={18} color={colors.bgNavy} weight="bold" />
            <Text style={styles.quickActionLabel}>Full Report</Text>
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={handleNavigateAI}
            style={styles.quickActionPill}
          >
            <Sparkle size={18} color={colors.accentGold} weight="fill" />
            <Text style={styles.quickActionLabel}>Ask AI</Text>
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation?.navigate('MainTabs')}
            style={styles.quickActionPill}
          >
            <CalendarBlank size={18} color={colors.bgNavy} weight="bold" />
            <Text style={styles.quickActionLabel}>Events</Text>
          </TouchableOpacity>
        </ScrollView>

        {/* 2×3 Activity Highlights Grid */}
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>TODAY'S HIGHLIGHTS</Text>
          <TouchableOpacity activeOpacity={0.7} onPress={handleNavigateReport}>
            <Text style={styles.viewAllText}>View Report ➔</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.gridContainer}>
          <View style={styles.gridRow}>
            <View style={styles.gridCol}>
              <HighlightCard
                category="meals"
                title="Ate 100% Lunch"
                subtitle="Injera & Vegetable Soup"
                time="12:30 PM"
                onPress={handleNavigateReport}
              />
            </View>
            <View style={styles.gridCol}>
              <HighlightCard
                category="sleep"
                title="Slept 1h 45m"
                subtitle="Peaceful afternoon nap"
                time="1:15 PM"
                onPress={handleNavigateReport}
              />
            </View>
          </View>

          <View style={styles.gridRow}>
            <View style={styles.gridCol}>
              <HighlightCard
                category="learning"
                title="Puzzles & Shapes"
                subtitle="Colors and numbers exercise"
                time="10:00 AM"
                onPress={handleNavigateReport}
              />
            </View>
            <View style={styles.gridCol}>
              <HighlightCard
                category="play"
                title="Outdoor Fun"
                subtitle="Playground & Ball games"
                time="11:15 AM"
                onPress={handleNavigateReport}
              />
            </View>
          </View>

          <View style={styles.gridRow}>
            <View style={styles.gridCol}>
              <HighlightCard
                category="mood"
                title="Happy & Bright"
                subtitle="Smiling & very active"
                time="All Day"
                onPress={handleNavigateReport}
              />
            </View>
            <View style={styles.gridCol}>
              <HighlightCard
                category="observation"
                title="Great Focus"
                subtitle="Concentrated on art"
                time="2:30 PM"
                onPress={handleNavigateReport}
              />
            </View>
          </View>
        </View>

        {/* Caregiver Note Quote Card */}
        <Text style={[styles.sectionTitle, { marginTop: 24 }]}>CAREGIVER NOTE</Text>
        <View style={styles.caregiverCard}>
          <View style={styles.caregiverHeader}>
            <View style={styles.caregiverAvatar}>
              <Text style={styles.caregiverAvatarText}>SM</Text>
            </View>
            <View>
              <Text style={styles.caregiverName}>Sara Mekonnen</Text>
              <Text style={styles.caregiverRole}>Lead Caregiver • Sunflower Room</Text>
            </View>
            <Quotes size={24} color={colors.accentGold} weight="fill" style={styles.quoteIcon} />
          </View>

          <Text style={styles.caregiverNoteText}>
            "Liya was exceptionally engaged during group story time today! She happily shared her colored pencils with friends during art hour."
          </Text>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={handleNavigateChat}
            style={styles.replyButton}
          >
            <Text style={styles.replyButtonText}>↩ Reply to Sara</Text>
          </TouchableOpacity>
        </View>

        {/* Upcoming Event Card */}
        <Text style={[styles.sectionTitle, { marginTop: 24 }]}>UPCOMING EVENT</Text>
        <View style={styles.eventCard}>
          <View style={styles.eventDateBadge}>
            <Text style={styles.eventMonth}>AUG</Text>
            <Text style={styles.eventDay}>28</Text>
          </View>

          <View style={styles.eventDetails}>
            <Text style={styles.eventTitle}>Parent-Teacher Meeting</Text>
            <View style={styles.eventMetaRow}>
              <Clock size={14} color={colors.textSecondary} />
              <Text style={styles.eventMetaText}>4:00 PM - 5:30 PM</Text>
              <MapPin size={14} color={colors.textSecondary} style={{ marginLeft: 6 }} />
              <Text style={styles.eventMetaText}>Room 3</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  greetingHeader: {
    marginTop: 10,
    marginBottom: 16,
  },
  greetingTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  greetingSub: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  childCard: {
    backgroundColor: colors.bgNavy,
    borderRadius: radii.card,
    padding: 20,
    marginBottom: 24,
    ...shadows.card,
  },
  childCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  childName: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textWhite,
  },
  childGroup: {
    fontSize: 13,
    color: colors.borderCard,
    marginTop: 2,
  },
  checkinInfo: {
    marginTop: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  checkinText: {
    fontSize: 12.5,
    color: colors.bgMuted,
    fontWeight: '500',
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 12,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  viewAllText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.bgNavy,
  },
  quickActionsRow: {
    columnGap: 10,
    paddingBottom: 20,
  },
  quickActionPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgSurface,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: radii.pill,
    borderWidth: 1,
    borderColor: colors.borderLight,
    columnGap: 8,
    ...shadows.card,
  },
  quickActionLabel: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  gridContainer: {
    rowGap: 14,
  },
  gridRow: {
    flexDirection: 'row',
    columnGap: 14,
  },
  gridCol: {
    flex: 1,
  },
  caregiverCard: {
    backgroundColor: colors.bgNavyCard,
    borderRadius: radii.card,
    padding: 18,
    ...shadows.card,
  },
  caregiverHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 12,
    marginBottom: 12,
  },
  caregiverAvatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.accentGold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  caregiverAvatarText: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.bgNavy,
  },
  caregiverName: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textWhite,
  },
  caregiverRole: {
    fontSize: 12,
    color: colors.borderCard,
  },
  quoteIcon: {
    marginLeft: 'auto',
    opacity: 0.6,
  },
  caregiverNoteText: {
    fontSize: 14,
    fontWeight: '400',
    color: colors.bgMuted,
    lineHeight: 21,
    fontStyle: 'italic',
    marginBottom: 14,
  },
  replyButton: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: radii.pill,
  },
  replyButtonText: {
    fontSize: 12.5,
    fontWeight: '700',
    color: colors.textWhite,
  },
  eventCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 14,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  eventDateBadge: {
    width: 50,
    height: 52,
    borderRadius: radii.subcard,
    backgroundColor: colors.pastelYellow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  eventMonth: {
    fontSize: 11,
    fontWeight: '800',
    color: colors.pastelYellowText,
  },
  eventDay: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  eventDetails: {
    flex: 1,
  },
  eventTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  eventMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 4,
    marginTop: 4,
  },
  eventMetaText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
});
