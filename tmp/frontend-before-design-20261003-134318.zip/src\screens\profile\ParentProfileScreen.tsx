import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { TopBar } from '../../components/TopBar';
import { colors } from '../../theme/tokens';

export const ParentProfileScreen: React.FC = () => {
  return (
    <View style={styles.screen}>
      <TopBar />
      <View style={styles.content}>
        <Text style={styles.title}>Profile & Settings</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bgApp },
  content: { padding: 20 },
  title: { fontSize: 22, fontWeight: '700', color: colors.textPrimary },
});
