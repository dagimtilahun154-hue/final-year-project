import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ClipboardText, ShieldCheck, ChatCircleDots } from 'phosphor-react-native';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type OnboardingScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'Onboarding'>;
};

const SLIDES = [
  {
    id: 1,
    title: 'Know Their Day',
    subtitle:
      'Real-time activity logs, meal tracking, nap rest periods, and caregiver notes right at your fingertips.',
    bgColor: colors.pastelYellow,
    textColor: colors.pastelYellowText,
    Icon: ClipboardText,
  },
  {
    id: 2,
    title: 'Safe & Supportive',
    subtitle:
      'Authorized adult guardian verification during child pickup with strict legal safety disclaimers.',
    bgColor: colors.pastelGreen,
    textColor: colors.pastelGreenText,
    Icon: ShieldCheck,
  },
  {
    id: 3,
    title: 'Stay Connected',
    subtitle:
      'Direct 1-on-1 caregiver messaging, daycare store orders, event calendar, and helpful AI guidance.',
    bgColor: colors.pastelPurple,
    textColor: colors.pastelPurpleText,
    Icon: ChatCircleDots,
  },
];

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ navigation }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleNext = () => {
    if (currentIndex < SLIDES.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      navigation.navigate('Login');
    }
  };

  const handleSkip = () => {
    navigation.navigate('Login');
  };

  const activeSlide = SLIDES[currentIndex];
  const { Icon } = activeSlide;

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header Row with Skip Button */}
        <View style={styles.headerRow}>
          <TouchableOpacity activeOpacity={0.7} onPress={handleSkip}>
            <Text style={styles.skipText}>Skip</Text>
          </TouchableOpacity>
        </View>

        {/* Hero Card Container */}
        <View style={[styles.heroCard, { backgroundColor: activeSlide.bgColor }]}>
          <View style={styles.iconCircle}>
            <Icon size={56} color={activeSlide.textColor} weight="bold" />
          </View>
        </View>

        {/* Text Copy */}
        <View style={styles.textContainer}>
          <Text style={styles.slideTitle}>{activeSlide.title}</Text>
          <Text style={styles.slideSubtitle}>{activeSlide.subtitle}</Text>
        </View>

        {/* Bottom Navigation Controls */}
        <View style={styles.bottomContainer}>
          <View style={styles.paginationDots}>
            {SLIDES.map((_, index) => (
              <View
                key={index}
                style={[
                  styles.dot,
                  currentIndex === index && styles.dotActive,
                ]}
              />
            ))}
          </View>

          <PillButton
            title={currentIndex === SLIDES.length - 1 ? 'Sign In ➔' : 'Next ➔'}
            onPress={handleNext}
            style={styles.ctaButton}
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  container: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: 'space-between',
    paddingBottom: 24,
  },
  headerRow: {
    height: 44,
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  skipText: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textSecondary,
  },
  heroCard: {
    width: '100%',
    height: 240,
    borderRadius: radii.card,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
    ...shadows.card,
  },
  iconCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.bgSurface,
    alignItems: 'center',
    justifyContent: 'center',
    ...shadows.card,
  },
  textContainer: {
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  slideTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.textPrimary,
    marginBottom: 10,
    textAlign: 'center',
  },
  slideSubtitle: {
    fontSize: 15,
    fontWeight: '400',
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  bottomContainer: {
    width: '100%',
    alignItems: 'center',
    rowGap: 24,
  },
  paginationDots: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.borderCard,
  },
  dotActive: {
    width: 24,
    backgroundColor: colors.bgNavy,
  },
  ctaButton: {
    width: '100%',
  },
});
