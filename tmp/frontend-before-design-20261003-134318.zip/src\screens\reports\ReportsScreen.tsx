import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Clock, CaretDown, CaretRight } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { StatusBadge } from '../../components/StatusBadge';
import { colors, radii, shadows } from '../../theme/tokens';
import { useChild } from '../../context/ChildContext';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type ReportsScreenProps = {
  navigation?: StackNavigationProp<RootStackParamList>;
};

const MOCK_HISTORICAL_REPORTS = [
  {
    id: 1,
    date: 'Tuesday, Aug 25, 2026',
    status: 'present' as const,
    mood: 'Happy 😃',
    updateCount: 7,
    checkInTime: '8:04 AM',
    summary: 'Ate 100% Lunch • Slept 1h 45m • Great Art Session',
  },
  {
    id: 2,
    date: 'Monday, Aug 24, 2026',
    status: 'present' as const,
    mood: 'Playful 🎨',
    updateCount: 6,
    checkInTime: '8:10 AM',
    summary: 'Outdoor games • Ate 90% meals • Storytelling time',
  },
  {
    id: 3,
    date: 'Friday, Aug 21, 2026',
    status: 'present' as const,
    mood: 'Calm 😴',
    updateCount: 5,
    checkInTime: '8:00 AM',
    summary: 'Long nap • Puzzle building • Healthy snacks',
  },
  {
    id: 4,
    date: 'Thursday, Aug 20, 2026',
    status: 'absent' as const,
    mood: 'Absent',
    updateCount: 0,
    checkInTime: 'N/A',
    summary: 'Absent — Parent notified daycare (Family Event)',
  },
];

export const ReportsScreen: React.FC<ReportsScreenProps> = ({ navigation }) => {
  const { selectedChild } = useChild();
  const [activeFilter, setActiveFilter] = useState<'All' | 'This Week' | 'This Month'>('This Week');

  const handleOpenReport = (reportId: number) => {
    navigation?.navigate('FullDailyReport', { reportId });
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Title & Child Selector */}
        <View style={styles.headerContainer}>
          <Text style={styles.title}>Daily Reports History</Text>
          <TouchableOpacity activeOpacity={0.8} style={styles.childSelectorPill}>
            <Text style={styles.childSelectorText}>{selectedChild?.full_name || 'Liya Hana'}</Text>
            <CaretDown size={14} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
        </View>

        {/* Filter Chips Row */}
        <View style={styles.filterRow}>
          {(['All', 'This Week', 'This Month'] as const).map((filter) => (
            <TouchableOpacity
              key={filter}
              activeOpacity={0.8}
              onPress={() => setActiveFilter(filter)}
              style={[
                styles.filterChip,
                activeFilter === filter && styles.activeFilterChip,
              ]}
            >
              <Text
                style={[
                  styles.filterText,
                  activeFilter === filter && styles.activeFilterText,
                ]}
              >
                {filter}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Reports History Cards List */}
        <View style={styles.listContainer}>
          {MOCK_HISTORICAL_REPORTS.map((report) => (
            <TouchableOpacity
              key={report.id}
              activeOpacity={0.85}
              onPress={() => report.status !== 'absent' && handleOpenReport(report.id)}
              disabled={report.status === 'absent'}
              style={styles.reportCard}
            >
              {/* Card Header */}
              <View style={styles.cardHeader}>
                <View>
                  <Text style={styles.reportDate}>{report.date}</Text>
                  <Text style={styles.checkinSub}>Checked in at {report.checkInTime}</Text>
                </View>
                <StatusBadge status={report.status} />
              </View>

              {/* Card Body */}
              <Text style={styles.reportSummary}>{report.summary}</Text>

              {/* Card Footer Badges */}
              <View style={styles.cardFooter}>
                <View style={styles.footerBadgeRow}>
                  {report.status !== 'absent' && (
                    <View style={styles.moodTag}>
                      <Text style={styles.moodText}>{report.mood}</Text>
                    </View>
                  )}
                  <View style={styles.updateBadge}>
                    <Clock size={13} color={colors.textSecondary} />
                    <Text style={styles.updateText}>{report.updateCount} updates</Text>
                  </View>
                </View>

                {report.status !== 'absent' && (
                  <View style={styles.viewLinkRow}>
                    <Text style={styles.viewLinkText}>View Report</Text>
                    <CaretRight size={14} color={colors.bgNavy} weight="bold" />
                  </View>
                )}
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  headerContainer: {
    marginTop: 10,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  childSelectorPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgMuted,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radii.pill,
    columnGap: 6,
  },
  childSelectorText: {
    fontSize: 12.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  filterRow: {
    flexDirection: 'row',
    columnGap: 8,
    marginBottom: 20,
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: radii.pill,
    backgroundColor: colors.bgSurface,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  activeFilterChip: {
    backgroundColor: colors.bgNavy,
    borderColor: colors.bgNavy,
  },
  filterText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  activeFilterText: {
    color: colors.textWhite,
    fontWeight: '700',
  },
  listContainer: {
    rowGap: 14,
  },
  reportCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  reportDate: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  checkinSub: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  reportSummary: {
    fontSize: 13.5,
    color: colors.textSecondary,
    lineHeight: 19,
    marginBottom: 14,
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 10,
    borderTopWidth: 1,
    borderColor: colors.borderLight,
  },
  footerBadgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 8,
  },
  moodTag: {
    backgroundColor: colors.pastelPink,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radii.pill,
  },
  moodText: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.pastelPinkText,
  },
  updateBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgMuted,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: radii.pill,
    columnGap: 4,
  },
  updateText: {
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  viewLinkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 4,
  },
  viewLinkText: {
    fontSize: 12.5,
    fontWeight: '700',
    color: colors.bgNavy,
  },
});
