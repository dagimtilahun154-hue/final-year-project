import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MagnifyingGlass, CaretRight, NotePencil } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { colors, radii, shadows } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type MessagesScreenProps = {
  navigation?: StackNavigationProp<RootStackParamList>;
};

const THREADS = [
  {
    id: 1,
    name: 'Sara Mekonnen',
    role: 'Lead Caregiver • Sunflower Room',
    lastMessage: 'Liya was exceptionally engaged during group story time today!',
    time: '10:45 AM',
    unread: 1,
    initials: 'SM',
    online: true,
  },
  {
    id: 2,
    name: 'Abebe Worku',
    role: 'Activity Lead • Art & Music',
    lastMessage: 'Tomorrow we have water color painting! Please bring an extra apron if possible.',
    time: 'Yesterday',
    unread: 0,
    initials: 'AW',
    online: false,
  },
  {
    id: 3,
    name: 'Daycare Administration',
    role: 'Announcements & Billing',
    lastMessage: 'Reminder: Parent-Teacher meeting is scheduled for August 28 at 4:00 PM.',
    time: 'Aug 20',
    unread: 0,
    initials: 'DA',
    online: true,
  },
];

export const MessagesScreen: React.FC<MessagesScreenProps> = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleOpenThread = (threadId: number) => {
    navigation?.navigate('CaregiverChat', { threadId });
  };

  const filteredThreads = THREADS.filter(
    (t) =>
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.title}>Caregiver Messages</Text>
            <Text style={styles.subtitle}>Direct 1-on-1 communication with daycare staff</Text>
          </View>
        </View>

        {/* Search Input Bar */}
        <View style={styles.searchWrapper}>
          <MagnifyingGlass size={18} color={colors.textSecondary} weight="bold" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search messages or caregivers..."
            placeholderTextColor={colors.textMuted}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* Message Threads List */}
        <Text style={styles.sectionTitle}>RECENT CONVERSATIONS</Text>
        <View style={styles.threadsList}>
          {filteredThreads.map((thread) => (
            <TouchableOpacity
              key={thread.id}
              activeOpacity={0.82}
              onPress={() => handleOpenThread(thread.id)}
              style={styles.threadCard}
            >
              {/* Avatar with Online Dot */}
              <View style={styles.avatarContainer}>
                <View style={styles.avatarCircle}>
                  <Text style={styles.avatarText}>{thread.initials}</Text>
                </View>
                {thread.online && <View style={styles.onlineDot} />}
              </View>

              {/* Message Content */}
              <View style={styles.threadContent}>
                <View style={styles.threadHeader}>
                  <Text style={styles.threadName}>{thread.name}</Text>
                  <Text style={styles.threadTime}>{thread.time}</Text>
                </View>

                <Text style={styles.threadRole}>{thread.role}</Text>
                <Text style={styles.lastMessage} numberOfLines={1}>
                  {thread.lastMessage}
                </Text>
              </View>

              {/* Unread Counter Badge or Chevron */}
              {thread.unread > 0 ? (
                <View style={styles.unreadBadge}>
                  <Text style={styles.unreadBadgeText}>{thread.unread}</Text>
                </View>
              ) : (
                <CaretRight size={16} color={colors.textMuted} weight="bold" />
              )}
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 110,
  },
  headerRow: {
    marginTop: 10,
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  subtitle: {
    fontSize: 13.5,
    color: colors.textSecondary,
    marginTop: 4,
  },
  searchWrapper: {
    height: 48,
    backgroundColor: colors.bgInput,
    borderRadius: radii.input,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    columnGap: 10,
    marginBottom: 24,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 12,
  },
  threadsList: {
    rowGap: 12,
  },
  threadCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 14,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.card,
  },
  avatarContainer: {
    position: 'relative',
  },
  avatarCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.bgNavy,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.textWhite,
  },
  onlineDot: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.statusPresentText,
    borderWidth: 2,
    borderColor: colors.bgSurface,
  },
  threadContent: {
    flex: 1,
  },
  threadHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  threadName: {
    fontSize: 15.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  threadTime: {
    fontSize: 11.5,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  threadRole: {
    fontSize: 11.5,
    color: colors.accentGold,
    fontWeight: '700',
    marginTop: 1,
  },
  lastMessage: {
    fontSize: 13,
    color: colors.textSecondary,
    marginTop: 4,
  },
  unreadBadge: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: colors.accentRed,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unreadBadgeText: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textWhite,
  },
});
