import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { MainTabNavigator } from './MainTabNavigator';
import { SplashScreen } from '../screens/auth/SplashScreen';
import { OnboardingScreen } from '../screens/auth/OnboardingScreen';
import { LoginScreen } from '../screens/auth/LoginScreen';
import { ForgotPasswordScreen } from '../screens/auth/ForgotPasswordScreen';
import { OTPScreen } from '../screens/auth/OTPScreen';
import { FullDailyReportScreen } from '../screens/reports/FullDailyReportScreen';
import { ChildProfileScreen } from '../screens/profile/ChildProfileScreen';
import { AuthorizedGuardiansScreen } from '../screens/profile/AuthorizedGuardiansScreen';
import { CaregiverChatScreen } from '../screens/messages/CaregiverChatScreen';
import { DaycareStoreScreen } from '../screens/store/DaycareStoreScreen';
import { ShoppingCartScreen } from '../screens/store/ShoppingCartScreen';
import { AIGuideScreen } from '../screens/ai/AIGuideScreen';
import { EventDetailScreen } from '../screens/calendar/EventDetailScreen';
import { AddGuardianScreen } from '../screens/profile/AddGuardianScreen';
import { OrderConfirmationScreen } from '../screens/store/OrderConfirmationScreen';
import { PickupVerificationScreen } from '../screens/profile/PickupVerificationScreen';

export type RootStackParamList = {
  Splash: undefined;
  Onboarding: undefined;
  Login: undefined;
  ForgotPassword: undefined;
  OTP: undefined;
  MainTabs: undefined;
  FullDailyReport: { reportId?: number };
  ChildProfile: { childId?: number };
  CaregiverChat: { threadId?: number };
  AIGuide: undefined;
  DaycareStore: undefined;
  ShoppingCart: undefined;
  Checkout: undefined;
  AuthorizedGuardians: undefined;
  AddGuardian: undefined;
  EventDetail: { eventId?: number };
  OrderConfirmation: { orderRef?: string; totalAmount?: number };
  PickupVerification: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

export const RootNavigator: React.FC = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Splash"
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
        <Stack.Screen name="OTP" component={OTPScreen} />
        <Stack.Screen name="MainTabs" component={MainTabNavigator} />
        <Stack.Screen name="FullDailyReport" component={FullDailyReportScreen} />
        <Stack.Screen name="ChildProfile" component={ChildProfileScreen} />
        <Stack.Screen name="AuthorizedGuardians" component={AuthorizedGuardiansScreen} />
        <Stack.Screen name="AddGuardian" component={AddGuardianScreen} />
        <Stack.Screen name="CaregiverChat" component={CaregiverChatScreen} />
        <Stack.Screen name="DaycareStore" component={DaycareStoreScreen} />
        <Stack.Screen name="ShoppingCart" component={ShoppingCartScreen} />
        <Stack.Screen name="OrderConfirmation" component={OrderConfirmationScreen} />
        <Stack.Screen name="AIGuide" component={AIGuideScreen} />
        <Stack.Screen name="EventDetail" component={EventDetailScreen} />
        <Stack.Screen name="PickupVerification" component={PickupVerificationScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
