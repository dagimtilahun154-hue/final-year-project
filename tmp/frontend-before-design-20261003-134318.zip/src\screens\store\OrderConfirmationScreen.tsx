import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CheckCircle, ShoppingBag, Receipt, House, ArrowRight } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';
import { RouteProp } from '@react-navigation/native';

type OrderConfirmationProps = {
  navigation: StackNavigationProp<RootStackParamList, 'OrderConfirmation'>;
  route: RouteProp<RootStackParamList, 'OrderConfirmation'>;
};

export const OrderConfirmationScreen: React.FC<OrderConfirmationProps> = ({ navigation, route }) => {
  const orderRef = route.params?.orderRef || '#ANK-8921';
  const totalAmount = route.params?.totalAmount || 1070;

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Success Icon Card Header */}
        <View style={styles.successHeader}>
          <View style={styles.checkIconBox}>
            <CheckCircle size={56} color={colors.statusPresentText} weight="fill" />
          </View>
          <Text style={styles.successTitle}>Order Placed Successfully!</Text>
          <Text style={styles.successSub}>
            Your daycare supply order has been received and confirmed by staff.
          </Text>
        </View>

        {/* Order Meta Ticket */}
        <View style={styles.ticketCard}>
          <View style={styles.ticketRow}>
            <Text style={styles.ticketLabel}>ORDER REFERENCE</Text>
            <Text style={styles.ticketValue}>{orderRef}</Text>
          </View>
          <View style={[styles.ticketRow, styles.rowBorder]}>
            <Text style={styles.ticketLabel}>TOTAL AMOUNT PAID</Text>
            <Text style={styles.ticketAmount}>{totalAmount} ETB</Text>
          </View>
          <View style={[styles.ticketRow, styles.rowBorder]}>
            <Text style={styles.ticketLabel}>ORDER STATUS</Text>
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>Ready for Daycare Handover</Text>
            </View>
          </View>
        </View>

        {/* Pickup Instructions Card */}
        <Text style={styles.sectionTitle}>HANDOVER & PICKUP INSTRUCTIONS</Text>
        <View style={styles.instructionsCard}>
          <View style={styles.instRow}>
            <ShoppingBag size={20} color={colors.bgNavy} weight="bold" />
            <View style={{ flex: 1 }}>
              <Text style={styles.instTitle}>Items Reserved at Front Desk</Text>
              <Text style={styles.instSub}>
                Caregivers will pack your items into Liya's cubby prior to afternoon pickup time.
              </Text>
            </View>
          </View>
          <View style={[styles.instRow, styles.rowBorder]}>
            <Receipt size={20} color={colors.bgNavy} weight="bold" />
            <View style={{ flex: 1 }}>
              <Text style={styles.instTitle}>Digital Receipt Sent</Text>
              <Text style={styles.instSub}>
                A confirmation copy has been dispatched to your email address and payment history.
              </Text>
            </View>
          </View>
        </View>

        {/* Action Buttons */}
        <PillButton
          title="Return to Parent Dashboard"
          showArrow
          onPress={() => navigation.navigate('MainTabs')}
          style={styles.homeBtn}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  successHeader: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 24,
    paddingHorizontal: 16,
  },
  checkIconBox: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.statusPresentBg,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    ...shadows.card,
  },
  successTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
    textAlign: 'center',
  },
  successSub: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    lineHeight: 18,
  },
  ticketCard: {
    backgroundColor: colors.bgNavy,
    borderRadius: radii.card,
    padding: 20,
    marginBottom: 24,
    ...shadows.card,
  },
  ticketRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  rowBorder: {
    borderTopWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    paddingTop: 12,
    marginTop: 4,
  },
  ticketLabel: {
    fontSize: 10,
    fontWeight: '800',
    color: colors.accentGold,
    letterSpacing: 0.6,
  },
  ticketValue: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.textWhite,
  },
  ticketAmount: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textWhite,
  },
  statusBadge: {
    backgroundColor: colors.statusPresentBg,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radii.pill,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '800',
    color: colors.statusPresentText,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 12,
  },
  instructionsCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    marginBottom: 24,
    ...shadows.card,
  },
  instRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    columnGap: 14,
    paddingVertical: 8,
  },
  instTitle: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  instSub: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
    lineHeight: 17,
  },
  homeBtn: {
    marginTop: 10,
  },
});
