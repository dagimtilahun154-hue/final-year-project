import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {
  House,
  ClipboardText,
  ChatCircleDots,
  CalendarBlank,
  User,
} from 'phosphor-react-native';

import { HomeScreen } from '../screens/home/HomeScreen';
import { ReportsScreen } from '../screens/reports/ReportsScreen';
import { MessagesScreen } from '../screens/messages/MessagesScreen';
import { CalendarScreen } from '../screens/calendar/CalendarScreen';
import { ProfileScreen } from '../screens/profile/ProfileScreen';
import { colors } from '../theme/tokens';

export type MainTabParamList = {
  Home: undefined;
  Reports: undefined;
  Messages: undefined;
  Calendar: undefined;
  Profile: undefined;
};

const Tab = createBottomTabNavigator<MainTabParamList>();

export const MainTabNavigator: React.FC = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: styles.tabBar,
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <View style={[styles.tabItem, focused && styles.activeTabItem]}>
              <House
                size={22}
                color={focused ? colors.bgNavy : colors.textMuted}
                weight={focused ? 'bold' : 'regular'}
              />
              <Text style={[styles.tabLabel, focused && styles.activeTabLabel]}>
                HOME
              </Text>
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Reports"
        component={ReportsScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <View style={[styles.tabItem, focused && styles.activeTabItem]}>
              <ClipboardText
                size={22}
                color={focused ? colors.bgNavy : colors.textMuted}
                weight={focused ? 'bold' : 'regular'}
              />
              <Text style={[styles.tabLabel, focused && styles.activeTabLabel]}>
                REPORTS
              </Text>
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Messages"
        component={MessagesScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <View style={[styles.tabItem, focused && styles.activeTabItem]}>
              <ChatCircleDots
                size={22}
                color={focused ? colors.bgNavy : colors.textMuted}
                weight={focused ? 'bold' : 'regular'}
              />
              <Text style={[styles.tabLabel, focused && styles.activeTabLabel]}>
                MESSAGES
              </Text>
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Calendar"
        component={CalendarScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <View style={[styles.tabItem, focused && styles.activeTabItem]}>
              <CalendarBlank
                size={22}
                color={focused ? colors.bgNavy : colors.textMuted}
                weight={focused ? 'bold' : 'regular'}
              />
              <Text style={[styles.tabLabel, focused && styles.activeTabLabel]}>
                CALENDAR
              </Text>
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <View style={[styles.tabItem, focused && styles.activeTabItem]}>
              <User
                size={22}
                color={focused ? colors.bgNavy : colors.textMuted}
                weight={focused ? 'bold' : 'regular'}
              />
              <Text style={[styles.tabLabel, focused && styles.activeTabLabel]}>
                PROFILE
              </Text>
            </View>
          ),
        }}
      />
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  tabBar: {
    position: 'absolute',
    bottom: Platform.OS === 'ios' ? 24 : 16,
    left: 16,
    right: 16,
    height: 68,
    borderRadius: 26,
    backgroundColor: colors.bgSurface,
    borderTopWidth: 0,
    elevation: 8,
    shadowColor: '#061224',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: 8,
  },
  tabItem: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 18,
    rowGap: 3,
  },
  activeTabItem: {
    backgroundColor: colors.bgMuted,
  },
  tabLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: colors.textMuted,
    letterSpacing: 0.4,
  },
  activeTabLabel: {
    color: colors.bgNavy,
    fontWeight: '800',
  },
});
