import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, CalendarBlank, Clock, MapPin, Check, Plus, User } from 'phosphor-react-native';
import { TopBar } from '../../components/TopBar';
import { PillButton } from '../../components/PillButton';
import { colors, radii, shadows } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';
import { RouteProp } from '@react-navigation/native';

type EventDetailProps = {
  navigation: StackNavigationProp<RootStackParamList, 'EventDetail'>;
  route: RouteProp<RootStackParamList, 'EventDetail'>;
};

export const EventDetailScreen: React.FC<EventDetailProps> = ({ navigation, route }) => {
  const eventId = route.params?.eventId || 1;
  const [isAttending, setIsAttending] = useState(true);

  // Mock Event Detail payload matching backend contract
  const eventData = {
    id: eventId,
    title: 'Annual Sunflower Cultural Parade & Picnic',
    category: 'Cultural Event',
    date: 'October 15, 2026',
    time: '09:00 AM - 01:00 PM',
    location: 'Main Daycare Playground & Courtyard',
    organizer: 'Sara Mekonnen (Lead Caregiver)',
    description:
      'Join us for our annual cultural celebration! Children will dress in traditional attire, perform short folk songs, and share homemade traditional snacks. Parents are warmly invited to participate and enjoy lunch together.',
    attendingCount: 18,
  };

  const handleToggleRSVP = () => {
    setIsAttending(!isAttending);
    Alert.alert(
      isAttending ? 'RSVP Cancelled' : 'RSVP Confirmed',
      isAttending
        ? 'You have updated your response for this event.'
        : 'Thank you! We look forward to seeing you at the event.'
    );
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <TopBar />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Nav Header */}
        <View style={styles.navHeader}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
          >
            <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
          </TouchableOpacity>
          <View>
            <Text style={styles.categoryBadge}>{eventData.category.toUpperCase()}</Text>
            <Text style={styles.headerTitle}>Event Overview</Text>
          </View>
        </View>

        {/* Hero Card */}
        <View style={styles.heroCard}>
          <Text style={styles.eventTitle}>{eventData.title}</Text>

          <View style={styles.metaRow}>
            <View style={styles.metaIconBox}>
              <CalendarBlank size={18} color={colors.bgNavy} weight="bold" />
            </View>
            <View>
              <Text style={styles.metaLabel}>DATE</Text>
              <Text style={styles.metaValue}>{eventData.date}</Text>
            </View>
          </View>

          <View style={styles.metaRow}>
            <View style={styles.metaIconBox}>
              <Clock size={18} color={colors.bgNavy} weight="bold" />
            </View>
            <View>
              <Text style={styles.metaLabel}>TIME</Text>
              <Text style={styles.metaValue}>{eventData.time}</Text>
            </View>
          </View>

          <View style={styles.metaRow}>
            <View style={styles.metaIconBox}>
              <MapPin size={18} color={colors.bgNavy} weight="bold" />
            </View>
            <View>
              <Text style={styles.metaLabel}>LOCATION</Text>
              <Text style={styles.metaValue}>{eventData.location}</Text>
            </View>
          </View>
        </View>

        {/* Description Card */}
        <Text style={styles.sectionTitle}>EVENT DETAILS & AGENDA</Text>
        <View style={styles.infoCard}>
          <Text style={styles.descriptionText}>{eventData.description}</Text>

          <View style={styles.organizerRow}>
            <View style={styles.organizerAvatar}>
              <User size={16} color={colors.textWhite} weight="bold" />
            </View>
            <View>
              <Text style={styles.organizerLabel}>ORGANIZER</Text>
              <Text style={styles.organizerName}>{eventData.organizer}</Text>
            </View>
          </View>
        </View>

        {/* RSVP Status Action Bar */}
        <View style={styles.rsvpCard}>
          <View>
            <Text style={styles.rsvpTitle}>YOUR ATTENDANCE</Text>
            <Text style={styles.rsvpSubtitle}>
              {isAttending ? 'You and 17 other families are attending' : 'Let the daycare know if you can join'}
            </Text>
          </View>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={handleToggleRSVP}
            style={[styles.rsvpBtn, isAttending && styles.rsvpBtnActive]}
          >
            {isAttending ? (
              <>
                <Check size={16} color={colors.statusPresentText} weight="bold" />
                <Text style={styles.rsvpBtnActiveText}>Attending</Text>
              </>
            ) : (
              <>
                <Plus size={16} color={colors.textWhite} weight="bold" />
                <Text style={styles.rsvpBtnText}>Join Event</Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        {/* Add to Phone Calendar Button */}
        <PillButton
          title="Add to Device Calendar"
          variant="secondary"
          onPress={() => Alert.alert('Calendar Sync', 'Event successfully added to your mobile calendar!')}
          style={styles.calendarSyncBtn}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  navHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
    columnGap: 12,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryBadge: {
    fontSize: 9.5,
    fontWeight: '800',
    color: colors.accentGold,
    letterSpacing: 0.6,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  heroCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.borderLight,
    rowGap: 16,
    marginBottom: 20,
    ...shadows.card,
  },
  eventTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.bgNavy,
    lineHeight: 26,
    marginBottom: 4,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 12,
  },
  metaIconBox: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.pastelYellow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  metaLabel: {
    fontSize: 9.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.6,
  },
  metaValue: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.textPrimary,
    marginTop: 1,
  },
  sectionTitle: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.8,
    marginBottom: 10,
  },
  infoCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.card,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
    marginBottom: 20,
    ...shadows.card,
  },
  descriptionText: {
    fontSize: 14,
    lineHeight: 22,
    color: colors.textPrimary,
    marginBottom: 16,
  },
  organizerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 10,
    paddingTop: 12,
    borderTopWidth: 1,
    borderColor: colors.borderLight,
  },
  organizerAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.bgNavy,
    alignItems: 'center',
    justifyContent: 'center',
  },
  organizerLabel: {
    fontSize: 9,
    fontWeight: '800',
    color: colors.textMuted,
    letterSpacing: 0.6,
  },
  organizerName: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  rsvpCard: {
    backgroundColor: colors.bgNavy,
    borderRadius: radii.card,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    ...shadows.card,
  },
  rsvpTitle: {
    fontSize: 10,
    fontWeight: '800',
    color: colors.accentGold,
    letterSpacing: 0.6,
  },
  rsvpSubtitle: {
    fontSize: 12,
    color: colors.textWhite,
    marginTop: 2,
    maxWidth: 190,
  },
  rsvpBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.accentGold,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: radii.pill,
    columnGap: 6,
  },
  rsvpBtnActive: {
    backgroundColor: colors.statusPresentBg,
  },
  rsvpBtnText: {
    fontSize: 12.5,
    fontWeight: '800',
    color: colors.bgNavy,
  },
  rsvpBtnActiveText: {
    fontSize: 12.5,
    fontWeight: '800',
    color: colors.statusPresentText,
  },
  calendarSyncBtn: {
    marginTop: 4,
  },
});
