import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  ArrowLeft,
  Phone,
  Paperclip,
  PaperPlaneRight,
  Checks,
  Image as ImageIcon,
} from 'phosphor-react-native';
import { colors, radii, shadows } from '../../theme/tokens';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/RootNavigator';

type CaregiverChatProps = {
  navigation: StackNavigationProp<RootStackParamList, 'CaregiverChat'>;
};

interface ChatMessage {
  id: number;
  sender: 'parent' | 'caregiver';
  text: string;
  time: string;
  photoUrl?: string;
}

export const CaregiverChatScreen: React.FC<CaregiverChatProps> = ({ navigation }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      sender: 'parent',
      text: 'Good morning Sara! Just checking in to see how Liya settled in for breakfast today?',
      time: '8:20 AM',
    },
    {
      id: 2,
      sender: 'caregiver',
      text: 'Good morning Hana! Liya arrived happily at 8:04 AM. She ate 100% of her oatmeal breakfast and is playing happily with her classmates.',
      time: '8:25 AM',
    },
    {
      id: 3,
      sender: 'caregiver',
      text: 'Here is a photo of Liya during creative painting time this morning! 🎨',
      time: '10:35 AM',
    },
    {
      id: 4,
      sender: 'parent',
      text: 'Thank you so much Sara! She looks so happy! ❤️',
      time: '10:40 AM',
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');

  const handleSend = () => {
    if (!inputMessage.trim()) return;
    const newMessage: ChatMessage = {
      id: Date.now(),
      sender: 'parent',
      text: inputMessage.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, newMessage]);
    setInputMessage('');
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      {/* Caregiver Header Bar */}
      <View style={styles.headerBar}>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => navigation.goBack()}
          style={styles.backBtn}
        >
          <ArrowLeft size={20} color={colors.textPrimary} weight="bold" />
        </TouchableOpacity>

        <View style={styles.avatarContainer}>
          <View style={styles.avatarCircle}>
            <Text style={styles.avatarText}>SM</Text>
          </View>
          <View style={styles.onlineDot} />
        </View>

        <View style={styles.headerInfo}>
          <Text style={styles.caregiverName}>Sara Mekonnen</Text>
          <Text style={styles.caregiverStatus}>● Online • Lead Caregiver</Text>
        </View>

        <TouchableOpacity activeOpacity={0.7} style={styles.callBtn}>
          <Phone size={18} color={colors.bgNavy} weight="bold" />
        </TouchableOpacity>
      </View>

      {/* Messages Stream */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.messagesContainer}
          showsVerticalScrollIndicator={false}
        >
          {/* Date Badge */}
          <View style={styles.dateBadgeContainer}>
            <View style={styles.dateBadge}>
              <Text style={styles.dateBadgeText}>Today, August 25</Text>
            </View>
          </View>

          {messages.map((msg) => {
            const isParent = msg.sender === 'parent';
            return (
              <View
                key={msg.id}
                style={[
                  styles.messageBubbleWrapper,
                  isParent ? styles.parentWrapper : styles.caregiverWrapper,
                ]}
              >
                <View
                  style={[
                    styles.messageBubble,
                    isParent ? styles.parentBubble : styles.caregiverBubble,
                  ]}
                >
                  <Text
                    style={[
                      styles.messageText,
                      isParent ? styles.parentText : styles.caregiverText,
                    ]}
                  >
                    {msg.text}
                  </Text>

                  {/* Message Meta Info */}
                  <View style={styles.metaRow}>
                    <Text
                      style={[
                        styles.timeText,
                        isParent ? styles.parentTime : styles.caregiverTime,
                      ]}
                    >
                      {msg.time}
                    </Text>
                    {isParent && (
                      <Checks size={15} color={colors.accentGold} weight="bold" />
                    )}
                  </View>
                </View>
              </View>
            );
          })}
        </ScrollView>

        {/* Bottom Input Action Bar */}
        <View style={styles.inputActionBar}>
          <TouchableOpacity activeOpacity={0.7} style={styles.attachBtn}>
            <Paperclip size={20} color={colors.textSecondary} weight="bold" />
          </TouchableOpacity>

          <TextInput
            style={styles.textInput}
            placeholder="Type a message to Sara..."
            placeholderTextColor={colors.textMuted}
            value={inputMessage}
            onChangeText={setInputMessage}
            multiline
          />

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={handleSend}
            style={styles.sendBtn}
          >
            <PaperPlaneRight size={18} color={colors.textWhite} weight="bold" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.bgApp,
  },
  headerBar: {
    height: 64,
    backgroundColor: colors.bgSurface,
    borderBottomWidth: 1,
    borderColor: colors.borderLight,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    columnGap: 12,
    ...shadows.card,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarContainer: {
    position: 'relative',
  },
  avatarCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.accentGold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.bgNavy,
  },
  onlineDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.statusPresentText,
    borderWidth: 1.5,
    borderColor: colors.bgSurface,
  },
  headerInfo: {
    flex: 1,
  },
  caregiverName: {
    fontSize: 15.5,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  caregiverStatus: {
    fontSize: 11.5,
    color: colors.statusPresentText,
    fontWeight: '600',
  },
  callBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  keyboardView: {
    flex: 1,
  },
  messagesContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 24,
  },
  dateBadgeContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  dateBadge: {
    backgroundColor: colors.bgMuted,
    paddingHorizontal: 14,
    paddingVertical: 4,
    borderRadius: radii.pill,
  },
  dateBadgeText: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.textSecondary,
  },
  messageBubbleWrapper: {
    marginBottom: 14,
    width: '100%',
    flexDirection: 'row',
  },
  parentWrapper: {
    justifyContent: 'flex-end',
  },
  caregiverWrapper: {
    justifyContent: 'flex-start',
  },
  messageBubble: {
    maxWidth: '82%',
    borderRadius: radii.card,
    padding: 14,
    ...shadows.card,
  },
  parentBubble: {
    backgroundColor: colors.bgNavy,
    borderBottomRightRadius: 4,
  },
  caregiverBubble: {
    backgroundColor: colors.bgSurface,
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 20,
  },
  parentText: {
    color: colors.textWhite,
    fontWeight: '400',
  },
  caregiverText: {
    color: colors.textPrimary,
    fontWeight: '400',
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    columnGap: 4,
    marginTop: 6,
  },
  timeText: {
    fontSize: 10.5,
  },
  parentTime: {
    color: colors.borderCard,
  },
  caregiverTime: {
    color: colors.textSecondary,
  },
  inputActionBar: {
    minHeight: 62,
    backgroundColor: colors.bgSurface,
    borderTopWidth: 1,
    borderColor: colors.borderLight,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    columnGap: 10,
  },
  attachBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.bgMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textInput: {
    flex: 1,
    minHeight: 40,
    maxHeight: 100,
    backgroundColor: colors.bgInput,
    borderRadius: radii.input,
    paddingHorizontal: 16,
    paddingVertical: 8,
    fontSize: 14,
    color: colors.textPrimary,
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.bgNavy,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
