import React from "react";
import { View } from "react-native";
import { ShieldCheck, Clock, CheckCircle } from "phosphor-react-native";
import {
  Page,
  Text,
  Card,
  Avatar,
  Badge,
  Notice,
  s,
} from "../../components/design/System";
import { artwork } from "../../theme/assets";
import { useDesign } from "../../context/DesignContext";
export function PickupVerificationScreen({ route }: any) {
  const { guardians } = useDesign();
  const guardian =
    guardians.find((g) => g.id === route.params?.guardianId) || guardians[0];
  return (
    <Page title="Pickup Status" back tabs activeTab="Profile">
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-around",
          marginBottom: 25,
        }}
      >
        {["Guardian", "Authorization", "Check-out"].map((x, i) => (
          <View key={x} style={{ alignItems: "center", gap: 7 }}>
            <View
              style={{
                width: 30,
                height: 30,
                borderRadius: 15,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor:
                  i < 2 && guardian.authorized ? "#96761E" : "#ECEAED",
              }}
            >
              <Text
                size={12}
                color={i < 2 && guardian.authorized ? "white" : "#959BA5"}
              >
                {i < 2 && guardian.authorized ? "✓" : i + 1}
              </Text>
            </View>
            <Text size={10} color="#818996">
              {x}
            </Text>
          </View>
        ))}
      </View>
      <Card
        tint={guardian.authorized ? "#EAF6ED" : "#FFF5D9"}
        style={{ alignItems: "center", paddingVertical: 30 }}
      >
        <ShieldCheck
          size={44}
          color={guardian.authorized ? "#538F69" : "#B09036"}
        />
        <Text size={21} weight="semibold" style={{ marginTop: 16 }}>
          {guardian.authorized ? "Authorized Guardian" : "Approval Pending"}
        </Text>
        <Text
          size={14}
          color="#648374"
          style={{ textAlign: "center", marginTop: 10 }}
        >
          {guardian.name}
          {guardian.authorized
            ? " is listed as an authorized guardian for Liya."
            : " is awaiting daycare approval."}
        </Text>
      </Card>
      <Card style={{ marginTop: 20 }}>
        <View style={s.row}>
          <Avatar source={artwork.child} />
          <View style={{ flex: 1 }}>
            <Text size={19}>Liya</Text>
            <Text size={12} color="#89919D">
              Sunflower Group
            </Text>
          </View>
          <Badge title="At Daycare" tone="neutral" />
        </View>
      </Card>
      <Card style={{ marginTop: 12 }}>
        <View style={s.row}>
          <Avatar
            source={guardian.photo ? artwork[guardian.photo] : undefined}
          />
          <View>
            <Text>{guardian.name}</Text>
            <Text size={12} color="#89919D">
              {guardian.relationship}
            </Text>
          </View>
        </View>
      </Card>
      <Card tint="#F0EFF3" style={{ marginTop: 24 }}>
        <View style={s.between}>
          <Text weight="medium">Pickup verification</Text>
          <Badge title="At daycare" tone="gold" />
        </View>
        <Text size={14} color="#747D8A" style={{ marginTop: 16 }}>
          Daycare staff will verify this guardian’s identity before completing
          check-out.
        </Text>
      </Card>
      <Notice>
        Parents can view pickup status here. Identity verification and check-out
        are completed by authorized daycare staff.
      </Notice>
    </Page>
  );
}
