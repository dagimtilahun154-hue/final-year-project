# Project orchestration

Use the `$software-orchestrator` skill for project definition, architecture, roadmap, repository recovery, cross-module feature work, quality gates, and release preparation. Treat `.orchestrator/state.json`, approved definition records, active tasks, and verified source/runtime evidence as the project navigation chain. Use metadata-first bounded context and update it after meaningful changes.
