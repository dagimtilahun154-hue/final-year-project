# Hallucination guard and evidence protocol

## Evidence classes

- `verified`: directly observed and reproducible.
- `inferred`: logical conclusion from cited verified items.
- `proposed`: recommendation or planned future state.
- `unknown`: insufficient evidence.
- `contradicted`: conflicting verified evidence exists.
- `stale`: once verified but repository/definition changed.

## Evidence ledger record

```json
{
  "id": "EV-0001",
  "claim": "Authentication integration tests pass",
  "state": "verified",
  "evidence": [
    {
      "type": "command",
      "value": "npm test -- auth.integration",
      "exit_code": 0,
      "observed_at": "ISO-8601 timestamp"
    }
  ],
  "scope": ["AUTH-004"],
  "limitations": [],
  "repository_fingerprint": "commit or index hash"
}
```

## Mandatory claim checks

### Repository claims

Before saying a file, function, route, schema, or package exists, observe it. Before saying it does not exist, use an appropriately scoped search and mention the scope if relevant.

### Requirements claims

Use approved definition IDs. Anything not approved is proposed, inferred, or unknown. Never silently convert an idea into a requirement.

### Implementation claims

A code change is `implemented`. It is not `working` until verified by relevant execution or tests. Static analysis alone may support only a limited inferred claim.

### Test claims

Record exact command, exit code, key counts, and environment. "Tests should pass" is proposed; "tests pass" requires observed success. Mention skipped tests and coverage gaps.

### Security claims

Do not call a system secure. State which checks were performed, findings, and limitations. Sensitive changes require threat-oriented review and, where available, appropriate scanners/tests.

### Performance claims

Do not call a change fast or scalable without measurements or a clearly labeled inference. Record workload, environment, baseline, and result.

### Deployment claims

Deployment requires target evidence, version/commit, successful deployment action, and smoke checks. Production readiness is separate from deployment.

## Contradiction protocol

When user intent, docs, metadata, code, tests, and runtime disagree:

1. Do not average them into a guess.
2. List the conflicting claims and evidence.
3. Apply precedence:
   - explicit current user decision;
   - approved current baseline/change request;
   - runtime/test evidence;
   - current source/config;
   - generated metadata;
   - old docs/checkpoints;
   - inference.
4. Determine whether the conflict is implementation drift, stale docs, stale metadata, or unclear intent.
5. Resolve safe implementation drift according to the baseline; ask only if product intent is genuinely ambiguous or high-impact.
6. Mark superseded/stale records and add a decision/evidence entry.

## Assumption budget

Keep assumptions few, visible, reversible, and low-impact. Every consequential assumption must include:

- reason it was needed;
- evidence supporting it;
- confidence;
- impact if wrong;
- validation plan;
- expiry/review trigger.

Do not continue on a high-impact low-confidence assumption.

## Failure honesty

When blocked or incomplete, state:

- what was attempted;
- observed evidence;
- what remains unknown;
- impact;
- smallest next decision/action.

Never fabricate progress to preserve momentum.
