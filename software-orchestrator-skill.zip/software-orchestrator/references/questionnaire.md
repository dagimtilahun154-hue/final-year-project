# System-definition interview protocol

Use this reference in DEFINE mode and for unresolved areas in RECOVER mode.

## Interview behavior

- Inspect available requirements, code, designs, and configuration first.
- Prefill known answers and ask only unresolved questions.
- Ask 3–7 related questions per batch, not a giant form.
- Offer concrete choices plus "recommend for me" where useful.
- Explain only decisions with meaningful consequences.
- Maintain an answer ledger after each batch.
- Distinguish required, preferred, undecided, inferred, and not applicable.
- Detect contradictions immediately and resolve them before baseline approval.

## Section A — Product charter

1. Working product name and one-sentence purpose.
2. Real-world problem and current workaround.
3. Primary users/customers and beneficiary.
4. Main outcome users must achieve.
5. Business/school/client/commercial context.
6. Success measures: adoption, time saved, errors reduced, revenue, compliance, etc.
7. Explicit non-goals and boundaries.
8. Existing system, data, or process being replaced/integrated.

## Section B — Delivery surfaces

1. Responsive web app, public website, admin dashboard, mobile app, desktop app, API, PWA, or combination.
2. Android/iOS targets and store delivery.
3. Offline operation and synchronization expectations.
4. Supported browsers, devices, screen sizes, and low-end constraints.
5. Separate portals/apps by role or one adaptive application.
6. Required source, builds, deployment, domains, certificates, and store artifacts.

## Section C — Roles and permissions

For each role capture:

- role name and purpose;
- account creation and approval method;
- data scope: own, assigned, branch, organization, global;
- view/create/update/delete/approve/reject/export/import permissions;
- user/role/settings/financial/system administration rights;
- impersonation/delegation rules if any;
- prohibited access;
- audit requirements;
- whether one user may hold multiple roles.

Generate a permission matrix and identify separation-of-duty conflicts.

## Section D — Features and workflows

For each feature capture:

- users/roles;
- trigger and desired outcome;
- inputs and outputs;
- happy path, alternate paths, failures, cancellation, retry, and recovery;
- validation and business rules;
- approvals and state transitions;
- notifications and reports;
- connected features/data/integrations;
- MVP/supporting/optional/future classification;
- measurable acceptance criteria.

Prioritize the smallest end-to-end vertical slices that deliver value.

## Section E — Data

1. Core entities, ownership, relationships, and lifecycle.
2. Data formats, files/media, maximum sizes, and volume estimates.
3. Sensitive/personal/financial/health/location data.
4. Retention, archival, deletion, legal hold, and user export.
5. Audit history and immutability requirements.
6. Import/migration and legacy data quality.
7. Backup, recovery targets, and disaster tolerance.
8. Realtime, offline, search, analytics, and reporting needs.
9. Database preference or permission to recommend.

## Section F — Technology and architecture

1. Required/preferred frontend, backend, mobile, database, and language.
2. REST/GraphQL/events/realtime needs.
3. Monolith/modular monolith/services preference and team constraints.
4. Hosting/cloud/on-premises and region requirements.
5. Authentication, file storage, email, SMS, payments, maps, analytics, monitoring.
6. Existing repositories, packages, standards, APIs, hardware, and vendor constraints.
7. Budget and acceptable recurring services.
8. CI/CD, environments, branching, release frequency, and support model.
9. Let the agent recommend choices when no preference exists; record tradeoffs in ADRs.

## Section G — UI/UX

1. Brand assets, colors, typography, logo, and design references.
2. Desired style: minimal, corporate, friendly, premium, technical, playful, etc.
3. Navigation model and information density.
4. Light/dark mode.
5. Languages, localization, date/number/currency formats, RTL needs.
6. Accessibility target and keyboard/screen-reader needs.
7. User technical literacy and connectivity constraints.
8. Required states: loading, empty, error, offline, permission denied, success.
9. Data visualization, print, receipt, PDF, Excel, or dashboard needs.

## Section H — Security and operations

1. Registration, invitations, verification, password reset, MFA, SSO.
2. Session duration, devices, revocation, and suspicious-login handling.
3. Authorization model and sensitive actions requiring reauthentication/approval.
4. Encryption, secrets, audit logs, privacy, compliance, consent.
5. Abuse, fraud, rate limits, file scanning, moderation as relevant.
6. Logging, monitoring, alerting, uptime, support, and incident response.
7. Environment ownership and access boundaries.

## Section I — Constraints and delivery

1. Deadline, milestones, budget, team, skill level, and availability.
2. Required frameworks, school/client rules, licensing, and documentation format.
3. Source code, deployed environment, APK/IPA, database, APIs, admin, tests.
4. User/admin/developer manuals, architecture, presentation, report, training.
5. Demo data, migration, maintenance, warranty/support, and ownership.
6. MVP definition, production definition, and acceptance authority.

## Baseline output

Generate:

- `docs/project/PROJECT_OVERVIEW.md`
- `docs/project/PRODUCT_REQUIREMENTS.md`
- `docs/project/ROLE_PERMISSION_MATRIX.md`
- `docs/project/FEATURE_CATALOG.md`
- `docs/project/USER_FLOWS.md`
- `.orchestrator/definition/product.json`
- `.orchestrator/definition/roles.json`
- `.orchestrator/definition/permissions.json`
- `.orchestrator/definition/features.json`
- `.orchestrator/definition/workflows.json`
- `.orchestrator/definition/technology.json`
- `.orchestrator/definition/ui.json`
- `.orchestrator/definition/security.json`
- `.orchestrator/definition/delivery.json`
- `.orchestrator/definition/open_questions.json`

Before approval, label the baseline `draft`. After explicit approval, set version `1.0`, status `approved`, timestamp, approver, and repository commit if available.
