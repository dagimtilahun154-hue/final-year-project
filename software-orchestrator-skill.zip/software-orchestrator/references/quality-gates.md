# Quality gates

Apply proportionately to project risk and delivery stage.

## Task gate

- Requirement and acceptance criteria linked.
- Change is coherent and scoped.
- Relevant behavior verified.
- Tests added/updated and observed.
- Validation, authorization, errors, edge cases considered.
- No secrets or unsafe defaults introduced.
- Relevant docs and metadata updated.
- Evidence ledger and checkpoint updated.
- Review findings resolved or explicitly accepted.

## Feature gate

- Complete user workflow including failures and recovery.
- Role/permission behavior verified in backend and UI where applicable.
- Data lifecycle and migrations verified.
- Integration contracts and fallback behavior tested.
- Accessibility/localization states checked as required.
- Requirement-to-test traceability has no critical gaps.

## MVP gate

- All approved MVP requirements complete.
- Critical end-to-end journeys pass.
- No unresolved critical/high defects accepted without owner decision.
- Seed/demo/migration path works.
- Basic security, backup, logging, and operational instructions exist.
- Deployment candidate can be built reproducibly.
- Known limitations and post-MVP backlog documented.
- Product owner acceptance recorded.

## Production-readiness gate

- Threat-oriented security review and dependency/secret checks.
- Production configuration and environment separation.
- Database migration rehearsal, backup, restore, rollback.
- Observability: logs, metrics/health, alert ownership as needed.
- Performance/load checks against defined budgets.
- Accessibility and supported-device/browser checks.
- Reliability, retries, idempotency, failure recovery where relevant.
- CI/CD gates, release versioning, artifact provenance.
- Operations runbook, incident and support ownership.
- User/admin/developer documentation and handover.
- Production approval.

## Deployment gate

- Approved target and credentials.
- Exact version/commit recorded.
- Backup and rollback ready.
- Deployment action succeeds.
- Migrations complete.
- Smoke tests and critical journey checks pass.
- Monitoring/health is normal.
- Release notes and evidence saved.

## Readiness report

Use an evidence-backed table with gate, status (`pass`, `partial`, `fail`, `not_applicable`), evidence IDs, owner, and remediation. Do not reduce readiness to a single percentage unless the scoring model and critical blockers are shown. Any critical gate failure overrides an apparently high numeric score.
