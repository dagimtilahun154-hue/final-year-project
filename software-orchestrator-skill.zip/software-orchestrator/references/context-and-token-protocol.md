# Context and token-efficiency protocol

## Objective

Spend context on decisions and relevant code, not repeated discovery. Metadata is a navigation aid, never a substitute for source verification.

## Progressive context ladder

### Tier 0 — Invocation metadata

Skill name/description only. Do not put project details in the skill itself.

### Tier 1 — Run recovery (target: very small)

Read:

- `.orchestrator/state.json`
- active task record
- latest checkpoint
- current Git status and compact diff summary

Outcome: know stage, goal, task, blockers, and freshness.

### Tier 2 — Task map

Read only task-linked records:

- requirement/feature IDs;
- module/file/symbol records;
- architecture decisions;
- related tests and dependencies;
- context-pack manifest.

### Tier 3 — Exact implementation

Open exact files and narrow ranges. Start with public interfaces, types, tests, and changed regions. Expand only as evidence requires.

### Tier 4 — Targeted discovery

Search likely directories and file types. Examples:

```bash
rg -n --glob 'src/**/*.{ts,tsx}' --glob '!**/*.generated.*' 'symbolName' src tests
rg -n -m 40 'POST /api/example|exampleHandler' src tests
find src -maxdepth 3 -type f | sort | head -200
```

### Tier 5 — Broad recovery

Only when indexes are stale/missing or the problem crosses unknown boundaries. Exclude vendor/build/cache/generated/binary areas and cap output.

## Active context pack

A context pack is a manifest, not a concatenation of the repository. It contains:

- task and acceptance criteria;
- relevant requirement/feature/ADR IDs;
- 5–12 primary files by default;
- related tests;
- dependency neighbors;
- recent changed hunks;
- unresolved questions;
- excluded areas and reason;
- maximum expansion rule.

If more than about 12 primary files are essential, split the task or justify the expansion.

## Compaction protocol

After a discovery or implementation milestone:

1. Write durable facts to metadata/evidence.
2. Write a checkpoint containing only decisions, verified facts, paths, test results, risks, and next action.
3. Do not carry raw command output or full files forward unless still necessary.
4. Prefer IDs and paths over repeated prose.
5. Mark stale facts instead of retaining conflicting summaries.

## Search discipline

- Metadata lookup before text search.
- Symbol/path search before content-wide search.
- Changed-files/diff search before repository-wide debugging.
- Test registry before scanning all tests.
- Dependency graph before opening callers manually.
- Never dump `node_modules`, `.git`, build output, coverage, generated assets, lockfiles, or large datasets unless directly relevant.
- Use limits (`-m`, `head`, depth, globs) and narrow patterns.
- Never use search output as proof that a feature works.

## Read discipline

- Read signatures/interfaces/types before full implementation.
- Read nearby tests to infer behavior, then verify against approved requirements.
- Read relevant lines, not whole large files, when tools permit.
- Reopen a file only if it changed or the active hypothesis requires it.
- Record the reason for reading unusually large artifacts.

## Output discipline

- Keep routine status under roughly 8 lines.
- Do not reproduce full requirements, architecture, or logs in every reply.
- Point to artifacts and IDs.
- For failures, show the key error and where full logs are saved.
- For review, report findings ordered by severity and evidence.

## Metadata freshness

Each generated record should include schema version, generated time, repository fingerprint/commit, generator, and stale flag. On mismatch:

1. treat metadata as a hint;
2. inspect source/diff;
3. regenerate affected indexes;
4. validate references;
5. clear stale only after verification.
