# Software Orchestrator Skill

A repository-aware agent skill for defining, planning, implementing, testing, documenting, and delivering software from idea to production while minimizing context usage and preventing unsupported claims.

## Main capabilities

- Adaptive project-definition questionnaire
- Roles and permission matrix
- Requirements, workflows, architecture, and roadmap
- Atomic task decomposition and traceability
- Repository intelligence metadata and bounded context packs
- Token-efficient navigation and search fallbacks
- Hallucination/evidence guard
- Context recovery and checkpoints across sessions
- Risk-based autonomy and approval gates
- Testing, review, security, release, and handover gates

## Install in one repository

Copy the `software-orchestrator` folder to:

```text
<repository>/.agents/skills/software-orchestrator/
```

Then start/restart Codex in that repository if needed.

## Install for all repositories

Copy it to:

```text
~/.agents/skills/software-orchestrator/
```

## Invoke

In Codex CLI or IDE:

```text
$software-orchestrator Define this new project and take it through an approved MVP.
```

For an existing project:

```text
$software-orchestrator Recover this repository, ask only unresolved system questions, build the metadata control plane, and continue the highest-priority ready task.
```

For a status/release audit:

```text
$software-orchestrator Audit this project for MVP and production readiness. Do not change code.
```

## First run

The skill should conduct or complete the system-definition interview, ask for baseline approval, then initialize `.orchestrator/` and `docs/project/`. You can explicitly direct it:

```text
Use DEFINE mode. Ask the questionnaire in small sections. Recommend the technology stack when I am unsure. Do not code until I approve baseline 1.0.
```

After approval:

```text
Continue autonomously through MVP. Ask me only for product decisions, costs, credentials, destructive actions, major architecture changes, or release approval.
```

## Included scripts

Run from your repository root, replacing `<skill-path>` with the installed skill directory:

```bash
python <skill-path>/scripts/bootstrap.py --root .
python <skill-path>/scripts/index_repo.py --root .
python <skill-path>/scripts/validate_metadata.py --root .
python <skill-path>/scripts/context_pack.py --root . --task TASK-ID --max-files 12
```

All scripts use the Python standard library.

## Important

The metadata layer improves navigation but is not authoritative when stale. The skill validates metadata against current repository state and treats source/runtime evidence as stronger than generated summaries.
