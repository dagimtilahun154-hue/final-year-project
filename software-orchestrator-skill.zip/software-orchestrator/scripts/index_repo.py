#!/usr/bin/env python3
"""Create a compact repository map and lightweight symbol/import index."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

IGNORE_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "vendor", "dist", "build", "out",
    "coverage", ".next", ".nuxt", ".cache", ".idea", ".vscode", "__pycache__",
    ".venv", "venv", "target", "bin", "obj", ".orchestrator"
}
TEXT_EXTS = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".kt", ".go", ".rs",
    ".cs", ".php", ".rb", ".vue", ".svelte", ".html", ".css", ".scss",
    ".sql", ".graphql", ".md", ".json", ".yaml", ".yml", ".toml", ".xml"
}
MAX_FILE_BYTES = 1_000_000
SYMBOL_PATTERNS = [
    re.compile(r"^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)", re.M),
    re.compile(r"^\s*(?:export\s+)?class\s+([A-Za-z_$][\w$]*)", re.M),
    re.compile(r"^\s*(?:export\s+)?(?:interface|type|enum)\s+([A-Za-z_$][\w$]*)", re.M),
    re.compile(r"^\s*def\s+([A-Za-z_]\w*)", re.M),
    re.compile(r"^\s*class\s+([A-Za-z_]\w*)", re.M),
]
IMPORT_PATTERNS = [
    re.compile(r"from\s+['\"]([^'\"]+)['\"]"),
    re.compile(r"require\(\s*['\"]([^'\"]+)['\"]\s*\)"),
    re.compile(r"^\s*(?:from|import)\s+([\w.]+)", re.M),
]


def git_value(root: Path, *args: str) -> str | None:
    try:
        return subprocess.check_output(["git", "-C", str(root), *args], text=True, stderr=subprocess.DEVNULL).strip() or None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def iter_files(root: Path):
    for current, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in IGNORE_DIRS and not d.startswith(".pytest_cache"))
        for name in sorted(files):
            path = Path(current) / name
            if path.suffix.lower() not in TEXT_EXTS:
                continue
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if size > MAX_FILE_BYTES:
                continue
            yield path, size


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    metadata_dir = root / ".orchestrator/metadata"
    metadata_dir.mkdir(parents=True, exist_ok=True)

    files_out = []
    symbols = {}
    imports = {}
    languages = Counter()
    fingerprint = hashlib.sha256()

    for path, size in iter_files(root):
        rel = path.relative_to(root).as_posix()
        digest = sha256_file(path)
        fingerprint.update(rel.encode())
        fingerprint.update(digest.encode())
        languages[path.suffix.lower() or "<none>"] += 1
        files_out.append({"path": rel, "size": size, "sha256": digest})

        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        found_symbols = []
        for pattern in SYMBOL_PATTERNS:
            found_symbols.extend(pattern.findall(text))
        if found_symbols:
            symbols[rel] = sorted(set(found_symbols))[:200]
        found_imports = []
        for pattern in IMPORT_PATTERNS:
            found_imports.extend(pattern.findall(text))
        if found_imports:
            imports[rel] = sorted(set(found_imports))[:200]

    now = datetime.now(timezone.utc).isoformat()
    common = {
        "schema_version": "1.0",
        "generated_at": now,
        "generator": "software-orchestrator/index_repo.py",
        "repository": {
            "root_name": root.name,
            "commit": git_value(root, "rev-parse", "HEAD"),
            "branch": git_value(root, "branch", "--show-current"),
            "fingerprint": fingerprint.hexdigest(),
        },
    }
    outputs = {
        "repository-map.json": {**common, "file_count": len(files_out), "languages": dict(languages), "files": files_out},
        "symbol-index.json": {**common, "symbols_by_file": symbols},
        "dependency-hints.json": {**common, "imports_by_file": imports},
    }
    for filename, payload in outputs.items():
        (metadata_dir / filename).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    state_path = root / ".orchestrator/state.json"
    if state_path.exists():
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
            state.setdefault("repository", {})
            state["repository"].update(common["repository"])
            state["metadata_status"] = "current"
            state["updated_at"] = now
            state_path.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
        except (json.JSONDecodeError, OSError):
            pass

    print(json.dumps({"indexed_files": len(files_out), "fingerprint": fingerprint.hexdigest(), "metadata_dir": str(metadata_dir)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
