#!/usr/bin/env python3
"""Build a bounded task context manifest from orchestrator metadata."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def find_task(tasks_dir: Path, task_id: str):
    direct = tasks_dir / f"{task_id}.json"
    if direct.exists():
        return direct, load_json(direct, {})
    for path in tasks_dir.glob("*.json"):
        data = load_json(path, {})
        if data.get("id") == task_id:
            return path, data
    return None, None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--task", required=True)
    parser.add_argument("--max-files", type=int, default=12)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    task_path, task = find_task(root / ".orchestrator/tasks", args.task)
    if not task:
        print(json.dumps({"error": f"Task not found: {args.task}"}, indent=2))
        return 2

    candidates = []
    for key in ("likely_files", "files", "tests"):
        for item in task.get(key, []):
            if isinstance(item, str) and item not in candidates:
                candidates.append(item)

    feature_data = load_json(root / ".orchestrator/definition/features.json", {})
    feature_ids = set(task.get("feature_ids", []))
    items = feature_data.get("items", []) if isinstance(feature_data, dict) else []
    for feature in items:
        if isinstance(feature, dict) and feature.get("id") in feature_ids:
            for key in ("files", "tests"):
                for item in feature.get(key, []):
                    if isinstance(item, str) and item not in candidates:
                        candidates.append(item)

    existing = [p for p in candidates if (root / p).exists()]
    missing = [p for p in candidates if not (root / p).exists()]
    selected = existing[: max(1, args.max_files)]
    overflow = existing[len(selected):]

    manifest = {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "task_id": args.task,
        "task_file": str(task_path.relative_to(root)) if task_path else None,
        "outcome": task.get("outcome"),
        "acceptance_criteria": task.get("acceptance_criteria", []),
        "requirement_ids": task.get("requirement_ids", []),
        "feature_ids": task.get("feature_ids", []),
        "primary_files": selected,
        "overflow_files": overflow,
        "missing_references": missing,
        "max_files": args.max_files,
        "expansion_rule": "Open overflow or search beyond these files only when evidence from the primary set requires it."
    }
    out_dir = root / ".orchestrator/metadata/context-packs"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{args.task}.json"
    out.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"context_pack": str(out.relative_to(root)), "selected": len(selected), "overflow": len(overflow), "missing": len(missing)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
