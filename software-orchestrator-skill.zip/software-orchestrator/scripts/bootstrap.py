#!/usr/bin/env python3
"""Initialize the Software Orchestrator control plane using only stdlib."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

DIRS = [
    ".orchestrator/definition",
    ".orchestrator/metadata",
    ".orchestrator/tasks",
    ".orchestrator/evidence",
    ".orchestrator/checkpoints",
    ".orchestrator/reports",
    "docs/project",
]

DOCS = {
    "PROJECT_OVERVIEW.md": "# Project Overview\n\nStatus: Draft\n",
    "PRODUCT_REQUIREMENTS.md": "# Product Requirements\n\nBaseline: Draft\n",
    "ROLE_PERMISSION_MATRIX.md": "# Role and Permission Matrix\n",
    "FEATURE_CATALOG.md": "# Feature Catalog\n",
    "USER_FLOWS.md": "# User Flows\n",
    "ARCHITECTURE.md": "# Architecture\n",
    "DATA_MODEL.md": "# Data Model\n",
    "API_SPECIFICATION.md": "# API Specification\n",
    "ROADMAP.md": "# Roadmap\n",
    "CURRENT_STATUS.md": "# Current Status\n\nStage: Definition\n",
    "DECISION_LOG.md": "# Decision Log\n",
    "RISK_REGISTER.md": "# Risk Register\n",
    "TEST_STRATEGY.md": "# Test Strategy\n",
    "RELEASE_CHECKLIST.md": "# Release Checklist\n",
    "CHANGELOG.md": "# Changelog\n",
}

DEFINITION_FILES = [
    "product.json", "roles.json", "permissions.json", "features.json",
    "workflows.json", "technology.json", "ui.json", "security.json",
    "delivery.json", "open_questions.json",
]


def write_if_missing(path: Path, content: str) -> bool:
    if path.exists():
        return False
    path.write_text(content, encoding="utf-8")
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="Repository root")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    created: list[str] = []

    for rel in DIRS:
        path = root / rel
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            created.append(rel + "/")

    now = datetime.now(timezone.utc).isoformat()
    state = {
        "schema_version": "1.0",
        "project_name": root.name,
        "mode": "DEFINE",
        "baseline": {"version": "draft", "status": "draft", "approved_at": None},
        "stage": "definition",
        "active_task": None,
        "blockers": [],
        "latest_checkpoint": None,
        "repository": {"commit": None, "branch": None, "index_fingerprint": None},
        "metadata_status": "missing",
        "updated_at": now,
    }
    state_path = root / ".orchestrator/state.json"
    if write_if_missing(state_path, json.dumps(state, indent=2) + "\n"):
        created.append(str(state_path.relative_to(root)))

    readme = """# Orchestrator Control Plane\n\nMachine-readable state, metadata, tasks, evidence, and checkpoints for the Software Orchestrator skill. Generated metadata is navigational and must be verified when stale.\n"""
    if write_if_missing(root / ".orchestrator/README.md", readme):
        created.append(".orchestrator/README.md")

    for name in DEFINITION_FILES:
        payload = {"schema_version": "1.0", "status": "draft", "items": [], "updated_at": now}
        path = root / ".orchestrator/definition" / name
        if write_if_missing(path, json.dumps(payload, indent=2) + "\n"):
            created.append(str(path.relative_to(root)))

    for name, content in DOCS.items():
        path = root / "docs/project" / name
        if write_if_missing(path, content):
            created.append(str(path.relative_to(root)))

    print(json.dumps({"root": str(root), "created": created, "preserved_existing": True}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
