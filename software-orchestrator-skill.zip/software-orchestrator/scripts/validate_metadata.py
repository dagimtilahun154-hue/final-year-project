#!/usr/bin/env python3
"""Validate orchestrator JSON and referenced repository paths."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

PATH_KEYS = {"path", "file", "migration", "model", "controller", "service", "documentation"}
PATH_LIST_KEYS = {"files", "likely_files", "frontend", "backend", "tests", "routes", "entry_points", "documentation"}


def walk(value, root: Path, location: str, missing: list[dict]):
    if isinstance(value, dict):
        for key, item in value.items():
            loc = f"{location}.{key}"
            if key in PATH_KEYS and isinstance(item, str) and item and not item.startswith(("http://", "https://", "/api/")):
                if not (root / item).exists():
                    missing.append({"location": loc, "path": item})
            elif key in PATH_LIST_KEYS and isinstance(item, list):
                for idx, p in enumerate(item):
                    if isinstance(p, str) and p and not p.startswith(("http://", "https://", "/api/")) and ("/" in p or "." in Path(p).name):
                        if not (root / p).exists():
                            missing.append({"location": f"{loc}[{idx}]", "path": p})
            walk(item, root, loc, missing)
    elif isinstance(value, list):
        for idx, item in enumerate(value):
            walk(item, root, f"{location}[{idx}]", missing)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    control = root / ".orchestrator"
    errors = []
    missing = []
    checked = 0

    if not control.exists():
        print(json.dumps({"valid": False, "errors": [".orchestrator does not exist"]}, indent=2))
        return 2

    for path in sorted(control.rglob("*.json")):
        checked += 1
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            walk(value, root, str(path.relative_to(root)), missing)
        except json.JSONDecodeError as exc:
            errors.append({"file": str(path.relative_to(root)), "error": str(exc)})
        except OSError as exc:
            errors.append({"file": str(path.relative_to(root)), "error": str(exc)})

    result = {"valid": not errors and not missing, "json_files_checked": checked, "json_errors": errors, "missing_references": missing}
    print(json.dumps(result, indent=2))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
